<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserPaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_payments', function (Blueprint $table) {
            $table->increments('id');

            $table->bigInteger('from_user_id')->unsigned();
            $table->bigInteger('from_stripe_id')->unsigned();

            $table->bigInteger('to_user_id')->unsigned();
            $table->bigInteger('to_stripe_id')->unsigned();

            $table->bigInteger('group_id')->unsigned();

            $table->decimal('total_sent', 10, 2); // $8
            $table->decimal('total_fee', 10, 2); // $2
            $table->decimal('total_charge', 10, 2); // $10

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('user_payments');
    }
}
