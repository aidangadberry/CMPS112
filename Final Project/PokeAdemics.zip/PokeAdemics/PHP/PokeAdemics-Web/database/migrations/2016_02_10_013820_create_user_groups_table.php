<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_groups', function (Blueprint $table) {
            $table->increments('id');

            $table->bigInteger('user_id')->unsigned();
            $table->bigInteger('group_id')->unsigned();
            $table->bigInteger('class_id')->unsigned();
            
            $table->boolean('group_owner')->default(false);
            $table->decimal('pool_paid', 5, 2);

            $table->boolean('winner')->nullable();
            $table->decimal('pool_won', 5, 2)->nullable();
            $table->integer('pool_place')->nullable();

            $table->boolean('grade_checker')->default(false);
            $table->boolean('grade_checked')->default(false);
            $table->boolean('grade_entered')->default(false);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('user_groups');
    }
}
