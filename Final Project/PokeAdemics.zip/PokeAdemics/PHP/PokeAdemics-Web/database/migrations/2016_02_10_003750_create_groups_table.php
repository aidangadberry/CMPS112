<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('groups', function (Blueprint $table) {
            $table->increments('id');

            $table->bigInteger('class_id')->unsigned();
            $table->bigInteger('owner_id')->unsigned()->nullable();
            $table->string('name');

            $table->boolean('public')->default(true);
            $table->boolean('joinable')->default(true);
            $table->boolean('class_default')->default(false);
            $table->boolean('complete')->default(false);

            $table->integer('users_count')->unsigned()->default(0);

            $table->decimal('buy_in', 5, 2);
            $table->decimal('pool_total', 8, 2);
            $table->tinyInteger('pool_payout_count')->default(1);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('groups');
    }
}
