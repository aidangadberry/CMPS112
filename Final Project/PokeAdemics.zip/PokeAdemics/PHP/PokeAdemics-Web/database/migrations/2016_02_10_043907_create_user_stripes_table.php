<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserStripesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_stripes', function (Blueprint $table) {
            $table->increments('id');

            $table->bigInteger('user_id')->unsigned();

            $table->string('managed_secret');
            $table->string('managed_publishable');
            $table->string('managed_id');

            $table->string('customer_id');

            $table->decimal('total_received', 10, 2)->default(0);
            $table->decimal('total_sent', 10, 2)->default(0);

            $table->boolean('transfers_enabled');
            $table->boolean('charges_enabled');
            $table->string('verification_status');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('user_stripes');
    }
}
