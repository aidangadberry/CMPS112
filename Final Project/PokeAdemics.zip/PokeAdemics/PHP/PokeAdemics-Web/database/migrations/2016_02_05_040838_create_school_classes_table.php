<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSchoolClassesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('school_classes', function (Blueprint $table) {
            $table->increments('id');

            $table->string('term_id');
            $table->string('class_number');
            $table->string('class_prefix');
            $table->string('class_id');
            $table->string('class_title');
            $table->string('type');
            $table->string('days');
            $table->string('times');
            $table->string('instructors');
            $table->string('location');
            $table->boolean('offset')->default(false);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('school_classes');
    }
}
