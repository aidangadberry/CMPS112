<?php

return [
    'PokeAdemics-iOS' => [
        'environment' => 'development',
        'certificate' => base_path() . env('CERT_PATH'),
        'passPhrase'  => env('CERT_PASS'),
        'service'     => 'apns'
    ],
];
