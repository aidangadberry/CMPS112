<?php

namespace App\Jobs;

use App\Jobs\Job;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Group;
use App\UserGroup;
use App\UserGrade;
use Log;
use DB;
use App\UserStripe;
use App\User;
use App\UserPayment;
use Config;
use PushNotification;
use App\SchoolClass;

class FinishGroup extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    protected $group;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Group $group)
    {
        $this->group = $group;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Log::info("FinishGroup(Group ID: " . $this->group->id . ")");
        \Stripe\Stripe::setApiKey(Config::get('services.stripe.secret'));

        $topCount = $this->group->pool_payout_count;
        $poolTotal = $this->group->pool_total;
        $usersCount = $this->group->users_count;
        $buyIn = $this->group->buy_in;
    
        $participants = UserGroup::where('user_groups.group_id', $this->group->id)
            ->join('user_grades', function ($query) {
                $query->on('user_grades.class_id', '=', 'user_groups.class_id');
                $query->on('user_grades.user_id', '=', 'user_groups.user_id');
            })->select(['user_grades.*', 'user_groups.*', DB::raw('user_groups.id as user_group_id')])->get();

        $participants = $participants->sortByDesc('grade_points');

        $previousPlace = 1;
        $previousValue = null; // previous grade points
        $placeCounter = 1; // total places (so it can be 1, 1, 3 for ties)

        $winners = collect();
        $losers = collect();

        $participants->each(function ($item, $key) use (&$previousValue, &$previousPlace, &$winners, &$losers, $topCount, &$placeCounter) {
            // if not enough winners, add them or
            // if there is already enough winners but a tie then add them

            if ($item->grade_points != $previousValue) {
                $previousPlace = $placeCounter;
            }

            if ($winners->count() < $topCount || ($item->grade_points == $previousValue && $winners->count() >= $topCount)) {
                $item->pool_place = $previousPlace;
                $item->winner = true;

                $winners->push($item);
            } else {
                $item->pool_place = $previousPlace;
                $losers->push($item);
            }

            $previousValue = $item->grade_points;
            $placeCounter += 1;

        });

        $winnersCount = $winners->count();

        // everyone won (all ties)
        if ($winnersCount == $usersCount) {
            UserGroup::where('group_id', $this->group->id)->update([
                'winner' => -1, //tie
                'pool_won' => 0,
                'pool_place' => 1
            ]);
        }
        // not everyone won
        elseif ($winnersCount < $usersCount) {
            $poolCut = ($poolTotal - ($winnersCount * $buyIn)) / $winnersCount;
            $loserPays = $poolCut / $losers->count();

            UserGroup::whereIn('user_id', $losers->pluck('user_id'))->where('group_id', $this->group->id)->update([

                'winner' => false,
                'pool_won' => ($buyIn - $loserPays),

            ]);

            // foreach winner set their status and make each loser pay him his cut
            $winners->each(function ($item, $key) use ($poolCut, $losers, $loserPays) {

                UserGroup::where('id', $item->user_group_id)->update([

                    'winner' => $item->winner,
                    'pool_won' => $poolCut,
                    'pool_place' => $item->pool_place,

                ]);

                $losers->each(function ($lose, $ind) use ($loserPays, $item) {

                    $winStripe = UserStripe::where('user_id', $lose->user_id)->first();
                    $loseStripe = UserStripe::where('user_id', $item->user_id)->first();

                    $token = \Stripe\Token::create([
                        "customer" => $loseStripe->customer_id,
                    ], ["stripe_account" => $winStripe->managed_id]);

                    $charge = \Stripe\Charge::create([
                        'amount' => ($loserPays * 100), //cents
                        'currency' => 'usd',
                        'source' => $token->id,
                        'expand' => ['balance_transaction'],
                    ], ['stripe_account' => $winStripe->managed_id]);


                    $winStripe->total_received += ($charge->balance_transaction->net / 100);
                    $loseStripe->total_sent += ($charge->amount / 100);

                    $winStripe->save();
                    $loseStripe->save();

                    $winUser = User::where('id', $item->user_id)->first();
                    $loseUser = User::where('id', $lose->user_id)->first();

                    $betGroup = Group::where('id', $item->group_id)->first();
                    $class = SchoolClass::where('class_number', $betGroup->class_id)->first();

                    $winMessage = $loseUser->cruz_first_name . ' ' . $loseUser->cruz_last_name . ' paid you $' . ($charge->balance_transaction->net / 100) . ' for winning the group: ' . $betGroup->name . ' (' . rtrim(strtok($class->class_id, '-')) . ')';
                    $loseMessage = 'You paid $' . ($charge->amount / 100) . ' to ' . $winUser->cruz_first_name . ' ' . $winUser->cruz_last_name . ' for losing the group: ' . $betGroup->name . ' (' . rtrim(strtok($class->class_id, '-')) . ')'; 

                    // sent to winner
                    PushNotification::app('PokeAdemics-iOS')
                        ->to($winUser->device_token)
                        ->send($winMessage);

                    // sent to loser
                    PushNotification::app('PokeAdemics-iOS')
                        ->to($loseUser->device_token)
                        ->send($loseMessage);

                    UserPayment::create([
                        'from_user_id' => $lose->user_id,
                        'from_stripe_id' => $loseStripe->id,
                        'to_user_id' => $item->user_id,
                        'to_stripe_id' => $winStripe->id,
                        'group_id' => $lose->group_id,
                        'total_sent' => $loserPays,
                        'total_fee' => ($charge->balance_transaction->fee / 100),
                        'total_charge' => ($charge->balance_transaction->net / 100),
                    ]);

                });

            });

            $losers->each(function ($item, $key) {

                UserGroup::where('id', $item->user_group_id)->update([

                    'pool_place' => $item->pool_place,

                ]);

            });
        }

        $this->group->complete = true;
        $this->group->joinable = false;
        $this->group->save();
    }
}
