<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Http\Controllers\UCSCController;
use App\SchoolClass;

class FetchAllClasses extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'classes:fetch {term_id : The ID of the school term} {offset=false : Boolean if term is during the summer}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Insert all of the classes of a specific term into the database.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $termId = $this->argument('term_id');
        $offset = $this->argument('offset');

        $this->info("Term ID: " . $termId);
        $this->info("Offset: " . $offset);
        $this->info("Fetching...");

        $offsetVal = (strtolower($offset) == 'true' ? true : false);

        $controller = new UCSCController;
        $controller->insertClasses($termId, $offsetVal);

        $this->line('');

        $this->info("Finished! Inserted " . SchoolClass::all()->count() . ' classes.');
    }
}
