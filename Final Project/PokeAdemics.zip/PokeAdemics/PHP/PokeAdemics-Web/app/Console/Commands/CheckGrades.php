<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\UserGroup;
use App\UserGrade;
use App\UserClass;
use App\SchoolClass;
use App\Jobs\UpdateGrades;
use Crypt;
use Log;

class CheckGrades extends Command
{

    use DispatchesJobs;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:grades';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Checks grades for a certain class and fires a job to update grades if grades are out.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $user = UserGroup::where('grade_checker', true)->where('grade_entered', false)->where('grade_checked', false)->with('user')->first();

        if ($user) {
            Log::info("CheckGrades(UserGroup ID: " . $user->id . ")");
            $this->checkGrades($user);
        }
    }

    public function checkGrades($user)
    {
        $postURL = 'https://ais-cs.ucsc.edu/psc/csprd/EMPLOYEE/PSFT_CSPRD/c/SA_LEARNER_SERVICES.SSR_SSENRL_GRADE.GBL';

        $client = new \GuzzleHttp\Client([
            'defaults' => [
                'cookies' => true,
                'connect_timeout' => 5,
                'verify' => false,
                'timeout' => 5,
                'headers' => [
                   'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2633.3 Safari/537.36',
                ]
            ]
        ]);

        $post = [
            'userid' => $user->user->cruz_id,
            'pwd' => Crypt::decrypt($user->user->cruz_password),
        ];

        $login = $client->post($postURL, [
            'body' => $post,
        ]);

        $login = (string) $login->getBody();

        $html = new \Htmldom($login);
        $selectTerm = $html->find('.PSLEVEL1GRIDLABEL', 0);

        if ($selectTerm && $this->clean($selectTerm->plaintext) == 'Select a term then select Continue.') {
            $post = $this->termSelect(1);  //0 = current term (spring 2016), 1 = next term (winter 2016), ...
            $post['ICSID'] = $html->getElementById('ICSID')->value;

            $termSelection = $client->post($postURL, [
                'body' => $post,
            ]);

            $html = new \Htmldom((string) $termSelection->getBody());
        }

        $table = $html->find('.PSLEVEL1GRID', 0);
        $rows = $table->find('tr');

        $rowCount = 0;
        $grades = [];

        foreach ($rows as $row) {
            if (++$rowCount == 1) {
                continue;
            }

            if ($this->clean($row->find('td', 4)->find('span', 0)->plaintext) == null) {
                continue;
            }

            $grades[] = [
                'class_name'    => $this->clean($row->find('td', 0)->find('a', 0)->plaintext),
                'units'         => $this->clean($row->find('td', 2)->find('span', 0)->plaintext),
                'grading'       => $this->clean($row->find('td', 3)->find('span', 0)->plaintext),
                'grade'         => $this->clean($row->find('td', 4)->find('span', 0)->plaintext),
                'grade_points'  => $this->clean($row->find('td', 5)->find('span', 0)->plaintext),
                'description'   => $this->clean($row->find('td', 1)->find('span', 0)->plaintext),
            ];
        }

        // $grades[] = [
        //     'class_name'    => 'CS 112',
        //     'units'         => '5.00',
        //     'grading'       => 'Graded',
        //     'grade'         => 'A-',
        //     'grade_points'  => '18.00',
        //     'description'   => 'Compar Prog Lang',
        // ];

        // $grades[] = [
        //     'class_name'    => 'CMPE 12',
        //     'units'         => '5.00',
        //     'grading'       => 'Graded',
        //     'grade'         => 'B',
        //     'grade_points'  => '12.50',
        //     'description'   => 'Com Sys/Assmbly Lan',
        // ];

        foreach ($grades as $grade) {
            $class = SchoolClass::where('class_title', $grade['description'])->first();

            $count = UserGrade::where('class_id', $class->class_number)->where('user_id', $user->user_id)->count();

            if($count != 0) {
                continue;
            }

            $uGrade = UserGrade::create([
                'user_id' => $user->user_id,
                'class_id' => $class->class_number,
                'grade' => $grade['grade'],
                'grade_points' => $grade['grade_points']
            ]);

            Log::info("Created UserGrade (" . $uGrade->id . "): CheckGrades");

            UserGroup::where('user_id', $user->user_id)->where('class_id', $class->class_number)->where('grade_entered', false)->update([
                'grade_entered' => true,
                'grade_checked' => true,
            ]);

            $uGroup = UserGroup::where('class_id', $class->class_number)->first();

            $this->dispatch(new UpdateGrades($user));
        }

        UserGroup::where('id', $user->id)->update([
            'grade_checked' => true,
        ]);
    }

    private function clean($string)
    {
        $return = trim(str_replace('&nbsp;', ' ', $string));
        return ($return == '' ? null : $return);
    }

    private function termSelect($term)
    {
        return [
            'ICAction' => 'DERIVED_SSS_SCT_SSR_PB_GO',
            'SSR_DUMMY_RECV1$sels$1$$0' => $term,
        ];
    }

    private function between($string, $start, $end)
    {
        $string = ' ' . $string;

        $ini = strpos($string, $start);
        if ($ini == 0) {
            return '';
        }

        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;

        return substr($string, $ini, $len);
    }
}
