<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

use DB;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        // Commands\Inspire::class,
        Commands\FetchAllClasses::class,
        Commands\CheckGrades::class,
        Commands\FetchAllClasses::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('classes:fetch 2160')->everyMinute()->when(function() {
        
            return (DB::table('school_classes')->count() == 0);
        
        })->withoutOverlapping();

        $schedule->call(function() {
        
            DB::table('user_groups')->where('grade_checker', true)->where('grade_entered', false)->update(['grade_checked' => false]);
        
        })->when(function () {
           
            $checked = DB::table('user_groups')->where('grade_checker', true)->where('grade_checked', true)->count();
            $total = DB::table('user_groups')->where('grade_checker', true)->count();
            return ($checked == $total);
        
        });

        // $schedule->command('check:grades')->everyFiveMinutes()->withoutOverlapping();
        $schedule->command('check:grades')->everyMinute()->withoutOverlapping();
    }
}
