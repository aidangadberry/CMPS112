<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use DB;

class UserGroup extends Model
{
    protected $guarded = [];

    public function group()
    {
        return $this->hasOne('App\Group');
    }

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function gradesSorted()
    {
        // return $this->hasOne('App\UserGrade', 'class_id', 'class_id')->orderBy('grade_points', 'desc');
        // return $this->hasOne('App\UserGrade', 'class_id', 'class_id')->where('user_grades.user_id', '=', DB::raw('user_groups.user_id'))->orderBy('grade_points', 'desc');
        return $this->hasOne('App\UserGrade', 'class_id', 'class_id')->join('user_grades', 'user_grades.user_id', '=', 'user_groups.user_id')->orderBy('grade_points', 'desc');
    }
}
