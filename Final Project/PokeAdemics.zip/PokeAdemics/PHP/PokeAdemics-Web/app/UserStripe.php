<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserStripe extends Model
{
    protected $guarded = [];
}
