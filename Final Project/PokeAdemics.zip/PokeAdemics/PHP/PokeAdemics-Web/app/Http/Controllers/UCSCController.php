<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Encryption\DecryptException;
use Vinkla\Pusher\Facades\Pusher as LaravelPusher;
use App\Http\Controllers\Controller;
use App\Jobs\FetchUserDetails;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\SchoolClass;
use App\UserStripe;
use App\UserClass;
use App\UserGroup;
use App\Group;
use App\User;
use JWTAuth;
use Config;
use Crypt;
use Auth;
use DB;

class UCSCController extends Controller
{
    public function postLogin(Request $request)
    {
        $credentials = $request->only('cruz_id', 'cruz_password', 'password');

        try {
            if (! $token = JWTAuth::attempt($credentials)) {
                return response()->json(['error' => 'Invalid Cruz ID or Gold Password combination.'], 401);
            }
        } catch (JWTException $e) {
            return response()->json(['error' => 'Could not create authentication token.'], 500);
        }

        return response()->json(compact('token'));
    }

    public function postRegister(Request $request)
    {
        \Stripe\Stripe::setApiKey(Config::get('services.stripe.secret'));

        $exists = User::where('cruz_id', $request->input('cruz_id'))->count();

        if ($exists) {
            return response()->json(['error' => 'The Cruz ID is already signed up.']);
        }

        $postURL = 'https://ais-cs.ucsc.edu/psc/csprd/EMPLOYEE/PSFT_CSPRD/c/SA_LEARNER_SERVICES.SSR_SSENRL_CART.GBL';

        $client = new \GuzzleHttp\Client([
            'defaults' => [
                'cookies' => true,
                'connect_timeout' => 5,
                'verify' => false,
                'timeout' => 5,
                'headers' => [
                   'User-Agent'         => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2633.3 Safari/537.36',
                ]
            ]
        ]);

        $post = [
            'userid' => $request->input('cruz_id'),
            'pwd' => $request->input('cruz_password')
        ];

        $passed = true;
        $tries = 0;

        do {
            $login = $client->post($postURL, [
                'body' => $post,
            ]);

            $login = (string) $login->getBody();

            if (str_contains($login, 'Your User ID and/or Password are invalid.')) {
                return response()->json(['error' => 'Cruz ID and Gold Password are invalid.']);
            }

            if (str_contains($login, 'Faculty and students should not sign on here.')) {
                $passed = false;
                $tries++;
                sleep(1);
            }
        } while (!$passed && $tries < 3);

        if (!$passed) {
            return response()->json(['error' => 'UCSC server is malfunctioning. Please try again.']);
        }

        $bdate = $request->input('birth_year') . '-' . $request->input('birth_month') . '-' . $request->input('birth_day');

        $user = User::create([
            'cruz_id' => $request->input('cruz_id'),
            'cruz_password' => Crypt::encrypt($request->input('cruz_password')),
            'password' => bcrypt($request->input('cruz_password')),
            'birth_date' => $bdate,
            'cruz_email' => $request->input('cruz_id') . '@ucsc.edu',
            'device_token' => $request->input('device_token'),
        ]);

        $this->dispatch(new FetchUserDetails($user));

        $account = \Stripe\Account::create([
            'country' => 'US',
            'managed' => true,
            'legal_entity[type]' => 'individual',
            'legal_entity[first_name]' => $user->cruz_first_name,
            'legal_entity[last_name]' => $user->cruz_last_name,
            'legal_entity[dob][day]' => $user->birth_date->day,
            'legal_entity[dob][month]' => $user->birth_date->month,
            'legal_entity[dob][year]' => $user->birth_date->year,
            'tos_acceptance[date]' => time(),
            'tos_acceptance[ip]' => request()->ip(),
            'external_account' => $request->input('first_token'),
        ]);

        $customer = \Stripe\Customer::create(array(
            "source" => $request->input('second_token'),
            "email" => $user->cruz_email,
        ));

        UserStripe::create([
            'user_id' => $user->id,
            'managed_secret' => $account->keys->secret,
            'managed_publishable' => $account->keys->publishable,
            'managed_id' => $account->id,
            'customer_id' => $customer->id,
            'transfers_enabled' => $account->transfers_enabled,
            'charges_enabled' => $account->charges_enabled,
            'verification_status' => $account->legal_entity->verification->status,
        ]);

        $token = JWTAuth::fromUser($user);

        return response()->json([
            'token' => $token,
            'channel' => 'user.' . $user->id,
        ]);
    }

    public function updateUser(User $user)
    {
        $postURL = 'https://ais-cs.ucsc.edu/psc/csprd/EMPLOYEE/PSFT_CSPRD/c/SA_LEARNER_SERVICES.SSR_SSENRL_CART.GBL';

        $client = new \GuzzleHttp\Client([
            'defaults' => [
                'cookies' => true,
                'connect_timeout' => 5,
                'verify' => false,
                'timeout' => 5,
                'headers' => [
                   'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2633.3 Safari/537.36',
                ]
            ]
        ]);

        $post = [
            'userid' => $user->cruz_id,
            'pwd' => Crypt::decrypt($user->cruz_password),
        ];

        $passed = true;
        $tries = 0;
        
        do {
            $login = $client->post($postURL, [
                'body' => $post,
            ]);

            $login = (string) $login->getBody();

            if (str_contains($login, 'Faculty and students should not sign on here.')) {
                $passed = false;
                $tries++;
                sleep(1);
            }
        } while (!$passed && $tries < 3);

        if (!$passed) {
            return false;
        }

        $html = new \Htmldom($login);

        if ($this->clean($html->getElementById('DERIVED_REGFRM1_TITLE1')->plaintext) == 'Select Term') {

            $termID = '2160'; //current term
            $termURL = 'https://ais-cs.ucsc.edu/psc/csprd/EMPLOYEE/PSFT_CSPRD/c/SA_LEARNER_SERVICES.SSR_SSENRL_CART.GBL?Page=SSR_SSENRL_CART&Action=A&ACAD_CAREER=UGRD&INSTITUTION=UCSCM&STRM=' . $termID . '&TargetFrameName=None';
            $termSelection = $client->get($termURL);

            $html = new \Htmldom((string) $termSelection->getBody());
        }

        $name = $this->clean($html->getElementById('DERIVED_SSTSNAV_PERSON_NAME')->plaintext);

        $table = $html->find('.PSLEVEL2GRIDWBO', 0);
        $rows = $table->find('tr');

        $rowCount = 0;
        $classes = [];

        foreach ($rows as $row) {
            if (++$rowCount == 1) {
                continue;
            }

            $status = $row->find('img.SSSIMAGECENTER', 0);
            if ($status && $status->alt == 'Enrolled') {
                $link = $row->find('a.PSHYPERLINK', 0);
                if (!$link) {
                    continue;
                }

                $classes[] = $this->between($link->plaintext, '(', ')');
            }
        }

        $insert = [];

        $carbon = \Carbon\Carbon::now();

        foreach ($classes as $class) {
            $insert[] = [
                'user_id' => $user->id,
                'class_id' => $class,
                'created_at' => $carbon,
                'updated_at' => $carbon,
            ];
        }

        UserClass::insert($insert);

        $user->cruz_first_name = strtok($name, ' ');
        $user->cruz_last_name = strtok(' ');
        $user->save();

        $select = ['class_number', 'class_prefix', 'class_id', 'class_title', 'days', 'instructors', 'times', 'location'];
        $pusher = SchoolClass::select($select)->whereIn('class_number', $classes)->get()->toArray();

        LaravelPusher::trigger('user.' . $user->id, 'register', ['data' => $pusher]);

        $groups = [];

        foreach ($classes as $class) {
            if (Group::where('class_id', $class)->where('class_default', true)->count() == 0) {
                $groups[] = [
                    'class_id' => $class,
                    'owner_id' => null,
                    'name' => 'Default group',
                    'public' => true,
                    'joinable' => true,
                    'class_default' => true,
                    'complete' => false,
                    'users_count' => 0,
                    'buy_in' => 5.00,
                    'pool_total' => 0,
                    'pool_payout_count' => 3,
                    'created_at' => $carbon,
                    'updated_at' => $carbon,
                ];
            }
        }

        if ($groups) {
            Group::insert($groups);
        }

        return true;
    }

    public function insertClasses($termId, $offset)
    {
        $client = new \GuzzleHttp\Client([
            'defaults'  => [
                'cookies'               => true,
                'timeout'               => 20.0,
                'connect_timeout'       => 20.0,
                'verify'                => false,
                'headers'               => [
                   'User-Agent'         => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2398.0 Safari/537.36',
                   'Accept'             => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Encoding'    => 'gzip, deflate, sdch',
                   'Accept-Language'    => 'en-US,en;q=0.8',
                   'Dnt'                => '1',
                   'Pragma'             => 'no-cache',
                   'Cache-Control'      => 'no-cache',
                   'Host'               => 'pisa.ucsc.edu',
                ],
            ]
        ]);

        $searchBody = [
            'action'                      => 'results',
            'binds[:term]'                => $termId,
            'binds[:reg_status]'          => 'all',
            'binds[:catalog_nbr_op]'      => '=',
            'binds[:instr_name_op]'       => '=',
            'binds[:crse_units_op]'       => '=',
        ];

        $searchOptions = [
            'body'               => $searchBody,
            'headers'            => [
                'Referer'         => 'https://pisa.ucsc.edu/class_search/index.php',
                'Content-Type'    => 'application/x-www-form-urlencoded',
            ],
        ];

        $search = $client->post('https://pisa.ucsc.edu/class_search/index.php', $searchOptions);

        $responseBody = [
            'action'                      => 'update_segment',
            'Rec_Dur'                     => '2000',
            'sel_col[class_nbr]'          => '1',
            'sel_col[class_id]'           => '1',
            'sel_col[class_title]'        => '1',
            'sel_col[type]'               => '1',
            'sel_col[days]'               => '1',
            'sel_col[times]'              => '1',
            'sel_col[instr_name]'         => '1',
            'sel_col[status]'             => '1',
            'sel_col[enrl_cap]'           => '1',
            'sel_col[enrl_tot]'           => '1',
            'sel_col[seats_avail]'        => '1',
            'sel_col[location]'           => '1',
            'sel_col[course_materials]'   => '1',
        ];

        $responseOptions = [
            'body'               => $responseBody,
            'headers'            => [
                'Referer'         => 'https://pisa.ucsc.edu/class_search/index.php',
                'Content-Type'    => 'application/x-www-form-urlencoded',
            ],
        ];

        $response = $client->post('https://pisa.ucsc.edu/class_search/index.php', $responseOptions);

        $html = new \Htmldom();
        $html->load($response->getBody());

        $tableName = 'school_classes';
        DB::table($tableName)->truncate();

        $rows = $html->find('#results_table tbody tr');

        foreach ($rows as $trow) {
            $spots = $trow->find('td');

            if (count($spots) == 0) {
                continue;
            }

            if ($offset) {
                $offset = 1;
            } else {
                $offset = 0;
            }

            $data = [
                'term_id'               => $termId,

                'class_number'          => htmlspecialchars_decode($spots[$offset +  0]->plaintext),
                'class_prefix'          => strtok(htmlspecialchars_decode($spots[$offset + 1]->plaintext), ' '),
                'class_id'              => htmlspecialchars_decode($spots[$offset + 1]->plaintext),
                'class_title'           => htmlspecialchars_decode($spots[$offset + 2]->plaintext),

                'type'                  => htmlspecialchars_decode($spots[$offset + 3]->plaintext),
                'days'                  => htmlspecialchars_decode($spots[$offset + 4]->plaintext),
                'times'                 => htmlspecialchars_decode($spots[$offset + 5]->plaintext),
                'instructors'           => htmlspecialchars_decode(trim(preg_replace('/\s\s+/', ' ', $spots[$offset + 6]->plaintext))),

                'location'              => htmlspecialchars_decode($spots[$offset + 11]->plaintext),
                
                'created_at'            => \Carbon\Carbon::now(),
                'updated_at'            => \Carbon\Carbon::now(),
            ];

            DB::table($tableName)->insert($data);
        }

        DB::statement('DELETE classes_1 FROM school_classes classes_1, school_classes classes_2 WHERE classes_1.id > classes_2.id AND classes_1.class_number = classes_2.class_number');
    }

    public function checkGrades()
    {
        $postURL = 'https://ais-cs.ucsc.edu/psc/csprd/EMPLOYEE/PSFT_CSPRD/c/SA_LEARNER_SERVICES.SSR_SSENRL_GRADE.GBL';

        $client = new \GuzzleHttp\Client([
            'defaults' => [
                'cookies' => true,
                'connect_timeout' => 5,
                'verify' => false,
                'timeout' => 5,
                'headers' => [
                   'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2633.3 Safari/537.36',
                ]
            ]
        ]);

        $post = [
            'userid' => 'agadberr',
            'pwd' => 'Aidang102695'
        ];

        $login = $client->post($postURL, [
            'body' => $post,
        ]);

        $login = (string) $login->getBody();

        if (str_contains($login, 'If your attempt fails, please contact your System Administrator.')) {
            die("server broke");
        }

        if (str_contains($login, 'Your User ID and/or Password are invalid.')) {
            die("wrong login details");
        }

        $html = new \Htmldom($login);
        $selectTerm = $html->find('.PSLEVEL1GRIDLABEL', 0);

        if($selectTerm && $this->clean($selectTerm->plaintext) == 'Select a term then select Continue.') {

            $post = $this->termSelect(2); //first term available
            $post['ICSID'] = $html->getElementById('ICSID')->value;

            $termSelection = $client->post('https://ais-cs.ucsc.edu/psc/csprd/EMPLOYEE/PSFT_CSPRD/c/SA_LEARNER_SERVICES.SSR_SSENRL_GRADE.GBL', [
                'body' => $post,
            ]);

            $html = new \Htmldom((string) $termSelection->getBody());
        }

        $table = $html->find('.PSLEVEL1GRID', 0);
        $rows = $table->find('tr');

        $rowCount = 0;
        $grades = [];

        foreach ($rows as $row) {
            if (++$rowCount == 1) {
                continue;
            }

            $grades[] = [
                'class_name'    => $this->clean($row->find('td', 0)->find('a', 0)->plaintext),
                'units'         => $this->clean($row->find('td', 2)->find('span', 0)->plaintext),
                'grading'       => $this->clean($row->find('td', 3)->find('span', 0)->plaintext),
                'grade'         => $this->clean($row->find('td', 4)->find('span', 0)->plaintext),
                'grade_points'  => $this->clean($row->find('td', 5)->find('span', 0)->plaintext),
                'description'   => $this->clean($row->find('td', 1)->find('span', 0)->plaintext),
            ];
        }

        dd($grades);
    }

    // public function gradeCycle()
    // {
    //     $users = UserGroup::where('grade_checker', true)->where('grade_checked', false)->with('user')->get();

    //     foreach($users as $user) {

    //     }
    // }

    public function getReset()
    {
        DB::table('users')->truncate();
        DB::table('user_classes')->truncate();
        DB::table('user_stripes')->truncate();
        DB::table('groups')->truncate();
    }

    private function clean($string)
    {
        $return = trim(str_replace('&nbsp;', ' ', $string));
        return ($return == '' ? null : $return);
    }

    private function termSelect($term)
    {
        return [
            'ICAction' => 'DERIVED_SSS_SCT_SSR_PB_GO',
            'SSR_DUMMY_RECV1$sels$1$$0' => $term,
        ];
    }

    private function between($string, $start, $end)
    {
        $string = ' ' . $string;

        $ini = strpos($string, $start);
        if ($ini == 0) {
            return '';
        }

        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;

        return substr($string, $ini, $len);
    }
}
