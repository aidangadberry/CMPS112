<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use JWTAuth;
use App\User;
use App\Group;
use App\UserGroup;
use App\SchoolClass;
use App\UserClass;
use DB;
use App\Jobs\FinishGroup;
use PushNotification;
use Log;

class APIController extends Controller
{
    public function getToken()
    {
        return JWTAuth::fromUser(User::find(1));
    }

    public function testToken()
    {
        $user = JWTAuth::parseToken()->authenticate();
        return 'Authd';
    }

    public function getGroups()
    {
        $user = JWTAuth::parseToken()->authenticate();

        $userClasses = UserClass::where('user_id', $user->id)->get()->pluck('class_id');

        $groups = Group::where('public', true)->where('joinable', true)->where('complete', false)->whereIn('class_id', $userClasses)->with(['userGroups' => function ($query) {

            $query
                ->join('users', 'users.id', '=', 'user_groups.user_id')
                ->select([
                    'user_groups.user_id', 'user_groups.group_id', 'users.cruz_id', 
                    'users.cruz_first_name', 'users.cruz_last_name',
                    'user_groups.pool_paid', 'users.id', 'user_groups.winner', 
                    'user_groups.pool_place', 'user_groups.pool_won',
                ]);

        }])->with(['schoolClass' => function ($query) {

            $query->addSelect([
                'school_classes.class_number', 'school_classes.class_number', 'school_classes.class_id',
                'school_classes.class_title', 'school_classes.times', 'school_classes.days', 'school_classes.instructors',
                'school_classes.location'
            ]);

        }])->get();

        return $groups;
    }

    public function joinGroup(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();

        $groupQB = Group::where('joinable', true)->where('complete', false)->where('public', true);
        $group = $groupQB->where('id', $request->input('group_id'))->first();

        if (!$group) {
            return response()->json(['error' => 'Group does not exist.']);
        }

        $classes = UserClass::where('user_id', $user->id)->get();

        if (!$classes->contains('class_id', $group->class_id)) {
            return response()->json(['error' => 'You are not enrolled in this class.']);
        }

        $exists = UserGroup::where('user_id', $user->id)->where('group_id', $group->id)->first();

        if ($exists) {
            return response()->json(['error' => 'You are already in this group.']);
        }

        $userGroupsCount = UserGroup::where('group_id', $request->input('group_id'))->count();

        UserGroup::create([
            'user_id' => $user->id,
            'group_id' => $group->id,
            'class_id' => $group->class_id,
            'group_owner' => false,
            'pool_paid' => $group->buy_in,
            'grade_checker' => ($userGroupsCount == 0 ? true : false),
            'grade_checked' => false,
            'grade_entered' => false,
        ]);

        $group->users_count += 1;
        $group->pool_total += $group->buy_in;
        $group->save();

        $data = [
            'cruz_first_name' => $user->cruz_first_name,
            'cruz_last_name' => $user->cruz_last_name,
            'cruz_id' => $user->cruz_id,
            'user_id' => $user->id,
            'group_id' => $group->id,
        ];

        if(!$group->class_default) {

            $class = SchoolClass::where('class_number', $group->class_id)->first();
            $groupUsers = User::join('user_groups', 'user_groups.user_id', '=', 'users.id')->where('user_groups.group_id', $group->id)->get();
            $deviceArray = [];

            foreach($groupUsers as $gUser) {
                $deviceArray[] = PushNotification::Device($gUser->device_token);
            }

            $devices = PushNotification::DeviceCollection($deviceArray);

            $message = $user->cruz_first_name . ' ' . $user->cruz_last_name . ' paid $' . $group->buy_in . ' to join a group you are in: ' . $group->name . ' (' . rtrim(strtok($class->class_id, '-')) . ')'; 

            PushNotification::app('PokeAdemics-iOS')
                    ->to($devices)
                    ->send($message);
        }   

        return response()->json(['error' => null, 'success' => true, 'data' => $data]);
    }

    public function createGroup(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();

        $class = SchoolClass::where('class_number', $request->input('class_id'))->first();

        if (!$class) {
            return response()->json(['error' => 'Class does not exist.']);
        }

        $classes = UserClass::where('user_id', $user->id)->get();

        if (!$classes->contains('class_id', $request->input('class_id'))) {
            return response()->json(['error' => 'You are not enrolled in this class.']);
        }

        $group = Group::create([
            'class_id' => $request->input('class_id'),
            'owner_id' => $user->id,
            'name' => $request->input('name'),
            'public' => true,
            'joinable' => true,
            'class_default' => false,
            'complete' => false,
            'users_count' => 1,
            'buy_in' => $request->input('buy_in'),
            'pool_total' => $request->input('buy_in'),
            'pool_payout_count' => $request->input('pool_payout_count'),
        ]);

        UserGroup::create([
            'user_id' => $user->id,
            'group_id' => $group->id,
            'class_id' => $group->class_id,
            'group_owner' => true,
            'pool_paid' => $group->buy_in,
            'grade_checker' => true,
            'grade_checked' => false
        ]);

        return response()->json(['error' => null, 'success' => true]);
    }

    public function joinedGroups()
    {
        $user = JWTAuth::parseToken()->authenticate();

        $userGroups = UserGroup::where('user_id', $user->id)->get()->pluck('group_id');

        $groups = Group::whereIn('id', $userGroups)->with(['userGroups' => function ($query) {

            $query
                ->join('users', 'users.id', '=', 'user_groups.user_id')
                ->select([
                    'user_groups.user_id', 'user_groups.group_id', 'users.cruz_id', 
                    'users.cruz_first_name', 'users.cruz_last_name',
                    'user_groups.pool_paid', 'users.id', 'user_groups.winner', 
                    'user_groups.pool_place', 'user_groups.pool_won',
                ]);

        }])->with(['schoolClass' => function ($query) {

            $query->addSelect([
                'school_classes.class_number', 'school_classes.class_number', 'school_classes.class_id',
                'school_classes.class_title', 'school_classes.times', 'school_classes.days', 'school_classes.instructors',
                'school_classes.location'
            ]);

        }])->get();

        return $groups;
    }

    public function getUser()
    {
        $user = JWTAuth::parseToken()->authenticate();

        $liveBets = UserGroup::where('user_id', $user->id)->whereNull('winner')->count();
        $completedBets = UserGroup::where('user_id', $user->id)->whereNotNull('winner')->count();

        $data = User::where('id', $user->id)->with(['classes' => function ($query) {

            $query->join('school_classes', 'user_classes.class_id', '=', 'school_classes.class_number');

        }])->first();

        $data->live_bets = $liveBets;
        $data->completed_bets = $completedBets;

        unset($data->cruz_password);

        return $data;
    }
}
