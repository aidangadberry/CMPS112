<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Config;

class StripeController extends Controller
{

    public function test()
    {
        \Stripe\Stripe::setApiKey(Config::get('services.stripe.secret'));

        $token1 = 'tok_17eJCqB6cdiaquPXCSavqkMO';
        $token2 = 'tok_17eJCpB6cdiaquPXPSlED2Mn';

        $account = \Stripe\Account::create([
            'country' => 'US',
            'managed' => true,
            'legal_entity[type]' => 'individual',
            'legal_entity[first_name]' => 'Jhin',
            'legal_entity[last_name]' => 'Gadberry',
            'legal_entity[dob][day]' => 31,
            'legal_entity[dob][month]' => 3,
            'legal_entity[dob][year]' => 1995,
            'tos_acceptance[date]' => time(),
            'tos_acceptance[ip]' => '169.233.6.92',
            'external_account' => $token1,
        ]);

        $customer = \Stripe\Customer::create(array(
            "description" => "Customer for test@example.com",
            "source" => $token2,
            "email" => "bradbernard@me.com",
        ));

        dd($account, $customer, $account->id, $account->keys->secret, $account->transfers_enabled, $customer->id);
    }

    public function charge()
    {
        // charge user 10 dollars
        \Stripe\Stripe::setApiKey(Config::get('services.stripe.secret'));
        // \Stripe\Charge::create(array(
        //   'amount' => 1000,
        //   'currency' => 'usd',
        //   //'source' => $customer->id,
        //   'source' => '',
        //   'destination' => 'acct_17bn9PKr5vX2ppnX'
        // ));

        $charge = \Stripe\Charge::create([
            "amount" => 1000, // amount in cents, again
            "currency" => "usd",
            "customer" => 'cus_7rWnr4TXuym9Yk',
        ]);

        dd($charge);
    }

    public function card()
    {
        return view('card');
    }
}
