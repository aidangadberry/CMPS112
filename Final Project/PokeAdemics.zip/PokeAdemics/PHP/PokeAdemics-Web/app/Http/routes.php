<?php

// use PushNotification;
// use Config;

Route::get('push', 'APIController@push');

// Helper routes
Route::group(['middleware' => ['web']], function () {
    Route::get('/test', 'APIController@testToken');
    Route::get('/token', 'APIController@getToken');
    Route::get('/card', 'StripeController@card');
});

# Prefix: api/
Route::group(['prefix' => 'api'], function() {

    # Prefix: v1/
    # Middleware: JWTAuth (Json Web Token Authentication)
    Route::group(['prefix' => 'v1', 'middleware' => ['jwt.auth']], function() {

        // Groups: /api/v1/groups
        Route::get('/groups', 'APIController@getGroups');
        Route::post('/groups', 'APIController@createGroup');
        Route::post('/groups/join', 'APIController@joinGroup');
        Route::get('/groups/joined', 'APIController@joinedGroups');

        // Authenticated User: /api/v1/me
        Route::get('/me', 'APIController@getUser');

    });

});

// Login 
Route::post('/login', 'UCSCController@postLogin');

// Register
Route::post('/register', 'UCSCController@postRegister');

// Reset
Route::get('/reset', 'UCSCController@getReset');

// Check grades
Route::get('/check', 'UCSCController@checkGrades');
//Route::get('/check', 'UCSCController@send_request');
