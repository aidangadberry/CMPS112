<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;

class Group extends Model
{
    protected $guarded = [];

    public function users() 
    {
        //return $this->hasManyThrough('App\User', 'App\UserGroup', 'group_id', 'user_id');
        //return $this->hasManyThrough('App\User', 'App\UserGroup', 'user_id', 'id');
        return $this->hasManyThrough('App\User', 'App\UserGroup', 'user_id', 'id');
        //return $this->hasMany('App\UserGroup', 'group_id');
    }

    public function userGroups()
    {
        return $this->hasMany('App\UserGroup');
    }

    public function schoolClass()
    {
        return $this->belongsTo('App\SchoolClass', 'class_id', 'class_number');
    }
}
