<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserGrade extends Model
{
    protected $guarded = [];
}
