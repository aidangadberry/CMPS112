<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    // protected $fillable = [
    //     'name', 'email', 'password',
    // ];

    protected $guarded = [];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token', 
    ];

    protected $dates = [
        'created_at', 'updated_at', 'birth_date'
    ];

    public function userGroups() 
    {
        return $this->hasMany('App\UserGroup');
    }

    public function classes()
    {
        return $this->hasMany('App\UserClass');
    }
}
