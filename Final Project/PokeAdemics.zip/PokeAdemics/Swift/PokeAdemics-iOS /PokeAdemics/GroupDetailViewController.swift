//
//  GroupDetailViewController.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 2/27/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit
import SnapKit
import ZFRippleButton
import Alamofire
import KeychainSwift
import JWTDecode
import SCLAlertView

extension UILabel {
    
    func boldRange(range: Range<String.Index>) {
        if let text = self.attributedText {
            let attr = NSMutableAttributedString(attributedString: text)
            let start = text.string.startIndex.distanceTo(range.startIndex)
            let length = range.startIndex.distanceTo(range.endIndex)
            attr.addAttributes([NSFontAttributeName: UIFont.boldSystemFontOfSize(self.font.pointSize), NSForegroundColorAttributeName: UIColor.greenColor()], range: NSMakeRange(start, length))
            self.attributedText = attr
        }
    }
    
    func boldSubstring(substr: String) {
        let range = self.text?.rangeOfString(substr)
        if let r = range {
            boldRange(r)
        }
    }
}

class GroupDetailViewController: UIViewController {

    var betGroup: BetGroup!
    var gravatar: Gravatar!
    
    @IBOutlet weak var createdBy: UILabel!
    @IBOutlet weak var createdTime: UILabel!
    
    @IBOutlet weak var classView: UIView!
    @IBOutlet weak var classTitle: UILabel!
    @IBOutlet weak var classTimes: UILabel!
    
    @IBOutlet weak var betView: UIView!
    @IBOutlet weak var buyIn: UILabel!
    @IBOutlet weak var poolTotal: UILabel!
    @IBOutlet weak var poolCount: UILabel!
    
    @IBOutlet weak var status: UILabel!
    
    @IBOutlet weak var users: UILabel!
    @IBOutlet weak var usersCount: UILabel!
    
    @IBOutlet weak var join: ZFRippleButton!
    
    @IBOutlet weak var usersTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeLabels()
        setRestraints()
        getUserID()
        alreadyJoined()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func initializeLabels() {
        let dateFormatter = NSDateFormatter()
        dateFormatter.timeStyle = .NoStyle
        dateFormatter.dateStyle = .ShortStyle
        
        self.title = betGroup.name
        
        self.createdBy.text = checkID()
        self.createdTime.text = "on " + dateFormatter.stringFromDate(betGroup.created_at)
        
        self.classTitle.text = betGroup.school_class.class_id + ": " + betGroup.school_class.class_title
        self.classTimes.text = betGroup.school_class.days + " " + betGroup.school_class.times
        
        self.buyIn.text = "Buy-in: $" + String(format: "%.2f", betGroup.buy_in)
        self.buyIn.boldSubstring("$" + String(format: "%.2f", betGroup.buy_in))
        self.poolTotal.text = "Total: $" + String(format: "%.2f", betGroup.pool_total)
        self.poolTotal.boldSubstring("$" + String(format: "%.2f", betGroup.pool_total))
        self.poolCount.text = "Prize pool split between " + String(betGroup.pool_payout_count) + " people"
        self.poolCount.boldSubstring(String(betGroup.pool_payout_count))
        
        self.users.text = "Users:"
        self.usersCount.text = "Total: " + String(betGroup.users.count)
        
        self.status.text = "Status: " + getStatus()
        status.boldSubstring(getStatus())
        
        self.join.setTitle("PAY $" + String(format: "%.2f", betGroup.buy_in) + " TO JOIN", forState: .Normal)

    }
    
    func checkID() -> String {
        if (betGroup.owner_id != ""){
            for user in betGroup.users {
                if (user.id == betGroup.owner_id){
                    return "Group created by " + user.cruz_first_name + " " + user.cruz_last_name
                }
            }
        }
        return "Group created"
    }
    
    func setRestraints(){
        creationRestraints()
        classInfoRestraints()
        buyInRestraints()
        userTableConstraints()
    }
    
    func creationRestraints(){
        
        createdBy.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(view).offset(79)
            make.centerX.equalTo(view)
        }
        
        createdTime.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(createdBy.snp_bottom).offset(5)
            make.centerX.equalTo(view)
        }
    }
    
    func classInfoRestraints(){
        classView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.right.equalTo(view).offset(-20)
            make.top.equalTo(createdTime.snp_bottom).offset(20)
        }
        
        classTitle.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(classView).offset(10)
            make.top.equalTo(classView).offset(5)
            make.height.equalTo(30)
        }
        
        classTimes.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(classTitle.snp_bottom).offset(5)
            make.left.equalTo(classView).offset(10)
            make.bottom.equalTo(classView).offset(-5)
            make.height.equalTo(classTitle)
        }
    }
    
    func buyInRestraints(){
        betView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.right.equalTo(view).offset(-20)
            make.top.equalTo(classView.snp_bottom).offset(20)
        }
        
        buyIn.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(betView).offset(10)
            make.top.equalTo(betView).offset(5)
            make.height.equalTo(30)
        }
        
        poolTotal.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(buyIn.snp_bottom).offset(5)
            make.left.equalTo(betView).offset(10)
            make.height.equalTo(buyIn)
        }
        
        poolCount.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(poolTotal.snp_bottom).offset(5)
            make.left.equalTo(betView).offset(10)
            make.bottom.equalTo(betView).offset(-5)
            make.height.equalTo(buyIn)
        }
        
        status.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(betView.snp_bottom).offset(20)
            make.height.equalTo(buyIn)
            make.centerX.equalTo(view)
        }
    }
    
    func userTableConstraints(){
        usersTable.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.right.equalTo(view).offset(-20)
            make.bottom.equalTo(view).offset(-75)
            make.height.equalTo(150)
        }
        
        users.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.bottom.equalTo(usersTable.snp_top).offset(-5)
        }
        
        usersCount.snp_makeConstraints { (make) -> Void in
            make.right.equalTo(view).offset(-20)
            make.bottom.equalTo(usersTable.snp_top).offset(-5)
        }
        
        join.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.right.equalTo(view).offset(-20)
            make.bottom.equalTo(users.snp_top).offset(-20)
            make.height.equalTo(40)
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("GroupDetailTableViewCell") as! GroupDetailTableViewCell
        
        let firstName = betGroup.users[indexPath.row].cruz_first_name
        let lastName = betGroup.users[indexPath.row].cruz_last_name
        let place = betGroup.users[indexPath.row].pool_place
        let winnings = betGroup.users[indexPath.row].pool_won
        
        if (betGroup.complete) {
            cell.userName.text = place + ".  " + firstName + " " + lastName + " won $" + String(format: "%.2f", winnings)
            cell.userName.boldSubstring("$" + String(format: "%.2f", winnings)
)
        } else {
            cell.userName.text = firstName + " " + lastName
        }
        
        let profileImage = cell.profileImage
        gravatar = Gravatar(emailAddress: betGroup.users[indexPath.row].cruz_id + "@ucsc.edu", defaultImage: .Identicon)
        profileImage.contentMode = .ScaleAspectFit
        
        let URL = gravatar.URL(size: 35)
        
        profileImage.af_setImageWithURL(
            URL,
            placeholderImage: nil,
            filter: nil,
            imageTransition: .None
        )
        
        profileImage.layer.borderWidth = 0.0
        profileImage.layer.borderColor = (UIColor.blackColor()).CGColor
        profileImage.layer.cornerRadius = 17.5
        profileImage.clipsToBounds = true
        profileImage.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return betGroup.users.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 45.0
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    @IBAction func joinGroup(sender: AnyObject) {
        let alertView = SCLAlertView()
        alertView.addButton("Yes") {
            self.joinGroup()
        }
        alertView.addButton("No") {}
        alertView.showCloseButton = false
        alertView.showInfo("Warning:", subTitle: "Are you sure you want to spend $" + String(format: "%.2f", betGroup.buy_in) + " to join this group?")
    }
    
    func joinGroup(){
        let parameters : [String : String] = [
            "group_id" : betGroup.id
        ]
        
        Alamofire.request(.POST, "https://pokeademics.com/api/v1/groups/join", parameters: parameters, headers: self.getHeaders())
            .responseJSON { response in
                
                let json = JSON(data: response.data!)
                print(json)
                if(json["error"].stringValue != "") {
                    
                } else {
                    self.betGroup.users.append(
                        UserGroup(
                            cruz_id: json["data"]["cruz_id"].stringValue,
                            cruz_first_name: json["data"]["cruz_first_name"].stringValue,
                            cruz_last_name: json["data"]["cruz_last_name"].stringValue,
                            group_id: json["data"]["group_id"].stringValue,
                            id: json["data"]["user_id"].stringValue,
                            pool_paid: json["data"]["pool_paid"].doubleValue,
                            winner: json["data"]["winner"].stringValue,
                            pool_place: json["data"]["pool_place"].stringValue,
                            pool_won: json["data"]["pool_won"].doubleValue
                        )
                    )
                }
                
                self.usersTable.reloadData()
                self.join.hidden = true
                self.usersCount.text = "Total: " + String(self.betGroup.users.count)
                let groupsVC = self.navigationController?.viewControllers[0] as! GroupsViewController
                groupsVC.getGroups()
                
                let vc = self.navigationController?.tabBarController as! HomeTabBarController
                
                let betsNavVC = vc.viewControllers![1] as! BetsNavigationController
                let betsVC = betsNavVC.viewControllers[0] as! BetsViewController
                betsVC.getGroups()
            }
    }
    
    func getHeaders() -> [String : String] {
        
        let keychain = KeychainSwift()
        let token = keychain.get("jwt_token")
            
        return [
            "Authorization" : "Bearer " + token!
        ]
    }
    
    func getUserID() -> String {
        do {
            let keychain = KeychainSwift()
            let token = keychain.get("jwt_token")
            let jwt = try decode(token!)
            return jwt.body["sub"]!.stringValue
        } catch {
            
        }
        return "0"
    }
    
    func alreadyJoined() {
        let current = getUserID()
        for user in betGroup.users {
            if (user.id == current){
                self.join.hidden = true
            }
        }
    }
    
    func createProfilePicture(){
        
    }
    
    func getStatus() -> String {
        if (betGroup.complete) {
            for user in betGroup.users {
                if (!(user.winner == "-1")){
                    return "COMPLETE"
                }
            }
            return "TIE"
        } else {
            return "IN PROGRESS"
        }
    }
}
