//
//  ClassesViewController.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/13/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit
import SnapKit
import ZFRippleButton

class ClassesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var classesTableView: UITableView!
    @IBOutlet weak var submitButton: ZFRippleButton!
    
    var classes = [SchoolClass]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "My Classes"
        
        self.setupNavigationBar()
        self.setRestraints()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ClassTableViewCell") as! ClassTableViewCell
        
        cell.classNameLabel.text = classes[indexPath.row].class_title
        cell.classLocationLabel.text = classes[indexPath.row].location
        cell.classInstructorsLabel.text = classes[indexPath.row].instructors
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return classes.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 100.0
    }
    
    func setRestraints(){
        // Table View
        classesTableView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(20)
            make.right.equalTo(view).offset(-20)
            make.top.equalTo(84)
            make.bottom.equalTo(submitButton.snp_top).offset(-20)
        }
        
        // Continue Button
        submitButton.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(20)
            make.right.equalTo(view).offset(-20)
            make.bottom.equalTo(view).offset(-20)
            make.height.equalTo(50)
        }
    }
    
    func setupNavigationBar() {
        self.navigationItem.setHidesBackButton(true, animated: false)
        
    }
    
    @IBAction func continuePressed(sender: AnyObject) {
        let myDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        myDelegate.switchToTabBar()
    }

}
