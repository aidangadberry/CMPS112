//
//  GroupAddViewController.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 3/1/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit
import ZFRippleButton
import TextFieldEffects
import SnapKit
import SwiftValidator
import Alamofire
import EZLoadingActivity
import SCLAlertView
import KeychainSwift

class DollarRule: RegexRule {
    
    static let regex = "^[1-9]\\d*(.\\d{2})?$"
    
    convenience init(message : String = "This must be a valid $ amount"){
        self.init(regex: DollarRule.regex, message : message)
    }
}

class PositiveRule: RegexRule {
    
    static let regex = "^[1-9]\\d*$"
    
    convenience init(message : String = "This must be a positive number"){
        self.init(regex: PositiveRule.regex, message : message)
    }
}

class GroupAddViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, ValidationDelegate {

    @IBOutlet weak var groupView: UIView!
    
    @IBOutlet weak var classPicker: UIPickerView!
    @IBOutlet weak var groupName: JiroTextField!
    @IBOutlet weak var groupNameError: UILabel!
    @IBOutlet weak var buyIn: JiroTextField!
    @IBOutlet weak var buyInError: UILabel!
    @IBOutlet weak var poolCount: JiroTextField!
    @IBOutlet weak var poolCountError: UILabel!
    
    @IBOutlet weak var create: ZFRippleButton!
    @IBOutlet weak var cancel: ZFRippleButton!
    
    @IBOutlet weak var navBar: UINavigationBar!
    
    var pickerData = [String]()
    var groups = [BetGroup]()
    var createValidator = Validator()
    var darkOverlay : UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.classPicker.layer.borderWidth = 2
        self.classPicker.layer.borderColor = UIColor.whiteColor().colorWithAlphaComponent(0.65).CGColor
        
        self.hideErrors()
        self.setupOverlay()
        self.initializeNavBar()
        self.setupValidators()
        self.setRestraints()
        
    }
    
    func getHeaders() -> [String : String] {
        
        let keychain = KeychainSwift()
        let token = keychain.get("jwt_token")
        
        return [
            "Authorization" : "Bearer " + token!
        ]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func cancelPressed(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func createPressed(sender: AnyObject) {
        self.hideErrors()
        self.createValidator.validate(self)
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return groups.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return groups[row].school_class.class_id + ": " + groups[row].school_class.class_title
    }
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView
    {
        
        //print("Selected Row: " + String(classPicker.selectedRowInComponent(0)) + " rendering row: " + String(row))
        let pickerLabel = UILabel()
        
        
        if(classPicker.selectedRowInComponent(0) != row) {
            pickerLabel.textColor = UIColor.whiteColor().colorWithAlphaComponent(0.55)
        } else {
            pickerLabel.textColor = UIColor.whiteColor()
        }
        
        pickerLabel.text =  groups[row].school_class.class_id + ": " + groups[row].school_class.class_title
        pickerLabel.font = UIFont(name: "AvenirNext-DemiBold", size: 18) // In this use your custom font
        pickerLabel.textAlignment = NSTextAlignment.Center
        
        return pickerLabel
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.classPicker.reloadComponent(0)
    }

    func initializeNavBar() {
        navBar.frame = CGRectMake(0, 0, self.view.frame.width, 64)
        navBar.barTintColor = UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 1)
        
        navBar.tintColor = UIColor.whiteColor()
        navBar.barStyle = UIBarStyle.Black
        
        navBar.titleTextAttributes = [
            NSFontAttributeName : UIFont(name: "Avenir-Heavy", size: 18.0)!,
            NSForegroundColorAttributeName : UIColor.whiteColor()
        ]
        
        navBar.topItem!.title = "Add Group"
        UIApplication.sharedApplication().statusBarStyle = .LightContent
    }
    
    func setupValidators() {
        createValidator.registerField(groupName, errorLabel: groupNameError, rules: [RequiredRule()])
        createValidator.registerField(buyIn, errorLabel: buyInError, rules: [RequiredRule(), FloatRule(message: "This must be a valid $ amount"), DollarRule()])
        createValidator.registerField(poolCount, errorLabel: poolCountError, rules: [RequiredRule(), PositiveRule()])
    }
    
    func validationFailed(errors:[UITextField:ValidationError]) {
        for (_, error) in createValidator.errors {
            error.errorLabel?.text = error.errorMessage
            error.errorLabel?.hidden = false
        }
    }
    
    func validationSuccessful() {
        self.hideErrors()

        let formatter = NSNumberFormatter()
        formatter.numberStyle = .CurrencyStyle
        
        let alertView = SCLAlertView()
        alertView.addButton("Yes") {
            self.processCreate()
        }
        alertView.addButton("No") {}
        alertView.showCloseButton = false
        alertView.showInfo("Warning:", subTitle: "You are about to spend " + formatter.stringFromNumber((buyIn.text! as NSString).floatValue)!/*String(format: "%.2f", buyIn.text!)*/ + " to create and join this group. Continue?")
    }
    
    func processCreate() {
        self.toggleForm(false)
        self.toggleOverlay(false)
        self.toggleLoading(true)
        
        EZLoadingActivity.show("Creating your group...", disableUI: true)
        
        let parameters : [String: String] = [
            "name" : groupName.text!,
            "buy_in" : buyIn.text!,
            "pool_payout_count" : poolCount.text!,
            "class_id" : groups[classPicker.selectedRowInComponent(0)].school_class.class_number
        ]
        
        Alamofire.request(.POST, "https://pokeademics.com/api/v1/groups", parameters: parameters, headers: self.getHeaders()).responseJSON { response in
                EZLoadingActivity.hide()
            
                let json = JSON(data: response.data!)
                
                if(json["error"].stringValue != "") {
                    self.instantOverlay(true)
                    SCLAlertView().showError("Whoops!", subTitle: json["error"].stringValue)
                    self.toggleForm(true)
                } else {
                    self.instantOverlay(false)
                    self.toggleForm(true)
                    self.toggleLoading(false)
                    print(self.parentViewController)
                    print(self.presentingViewController)
                    let vc = self.presentingViewController as! HomeTabBarController
                    let navVC = vc.viewControllers![0] as! GroupsNavigationController
                    (navVC.viewControllers[0] as! GroupsViewController).getGroups()
                    
                    let betsNavVC = vc.viewControllers![1] as! BetsNavigationController
                    let betsVC = betsNavVC.viewControllers[0] as! BetsViewController
                    betsVC.getGroups()
                    
                    self.dismissViewControllerAnimated(true, completion: nil)
                }
                
                print(json)
        }
    }
    
    func setupOverlay() {
        darkOverlay = UIView(frame: view.frame)
        darkOverlay.backgroundColor = UIColor.blackColor()
        darkOverlay.alpha = 0
        
        self.view.addSubview(darkOverlay)
    }
    
    func toggleOverlay(hidden : Bool) {
        self.view.bringSubviewToFront(darkOverlay)
        
        UIView.animateWithDuration(0.35, delay: 0, options: UIViewAnimationOptions.CurveLinear, animations: {
            
            self.darkOverlay.alpha = (hidden ? 0 : 0.65)
            
        }, completion: nil)
    }
    
    func instantOverlay(hidden : Bool) {
        self.darkOverlay.alpha = (hidden ? 0 : 0.65)
    }
    
    func toggleLoading(toggle : Bool) {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = toggle
    }
    
    func toggleForm(enabled : Bool){
        groupName.enabled = enabled
        buyIn.enabled = enabled
        poolCount.enabled = enabled
    }
    
    func hideErrors() {
        groupNameError.hidden = true
        buyInError.hidden = true
        poolCountError.hidden = true
    }
    
    func setRestraints() {
        groupView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.right.equalTo(view).offset(-20)
            make.centerY.equalTo(view)
        }
        
        classPicker.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(groupView).offset(10)
            make.left.equalTo(groupView).offset(10)
            make.right.equalTo(groupView).offset(-10)
            make.height.equalTo(75)
        }
        
        groupName.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(classPicker.snp_bottom)
            make.left.equalTo(groupView).offset(10)
            make.right.equalTo(groupView).offset(-10)
            make.height.equalTo(classPicker).offset(-10)
        }
        
        groupNameError.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(groupName).offset(5)
            make.right.equalTo(groupName)
        }
            
        buyIn.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(groupName.snp_bottom)
            make.left.equalTo(groupView).offset(10)
            make.right.equalTo(groupView).offset(-10)
            make.height.equalTo(groupName)
        }
        
        buyInError.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(buyIn).offset(5)
            make.right.equalTo(buyIn)
        }
        
        poolCount.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(buyIn.snp_bottom)
            make.left.equalTo(groupView).offset(10)
            make.right.equalTo(groupView).offset(-10)
            make.height.equalTo(groupName)
        }
        
        poolCountError.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(poolCount).offset(5)
            make.right.equalTo(poolCount)
        }
        
        create.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(poolCount.snp_bottom).offset(10)
            make.left.equalTo(groupView).offset(10)
            make.height.equalTo(groupName).offset(-20)
            make.bottom.equalTo(groupView).offset(-10)
        }
        
        cancel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(create)
            make.left.equalTo(create.snp_right).offset(10)
            make.right.equalTo(groupView).offset(-10)
            make.width.equalTo(create)
            make.height.equalTo(create)
            make.bottom.equalTo(groupView).offset(-10)
        }
    }
}