//
//  LeadViewController.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/11/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit

import HMSegmentedControl
import SwiftValidator
import ZFRippleButton
import TextFieldEffects
import Alamofire
import SwiftValidator
import PusherSwift
import Alamofire
import SCLAlertView
import EZLoadingActivity
import Stripe
import SnapKit
import KeychainSwift

class MonthRule: RegexRule {
    
    static let regex = "^(0?[1-9]|1[012])$"
    
    convenience init(message : String = "This must be a valid date"){
        self.init(regex: MonthRule.regex, message : message)
    }
}

class DayRule: RegexRule {
    
    static let regex = "^(0?[1-9]|[12][0-9]|3[01])$"
    
    convenience init(message : String = "This must be a valid date"){
        self.init(regex: DayRule.regex, message : message)
    }
}

class YearRule: RegexRule {
    
    static let regex = "^((19|20)\\d\\d)$"
    
    convenience init(message : String = "This must be a valid date"){
        self.init(regex: YearRule.regex, message : message)
    }
}

class LeadViewController: UIViewController, ValidationDelegate, STPPaymentCardTextFieldDelegate {
    
    @IBOutlet weak var loginCruzId: JiroTextField!
    @IBOutlet weak var loginGoldPassword: JiroTextField!
    @IBOutlet weak var loginButton: ZFRippleButton!
    
    @IBOutlet weak var registerCruzId: JiroTextField!
    @IBOutlet weak var registerGoldPassword: JiroTextField!
    @IBOutlet weak var registerButton: ZFRippleButton!
    @IBOutlet weak var registerMonth: JiroTextField!
    @IBOutlet weak var registerDay: JiroTextField!
    @IBOutlet weak var registerYear: JiroTextField!
    
    @IBOutlet weak var loginCruzIdError: UILabel!
    @IBOutlet weak var loginGoldPasswordError: UILabel!
    
    @IBOutlet weak var registerCruzIdError: UILabel!
    @IBOutlet weak var registerGoldPasswordError: UILabel!
    @IBOutlet weak var registerDateError: UILabel!
    
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var registerView: UIView!
    
    @IBOutlet weak var paymentField: STPPaymentCardTextField!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var titleSublabel: UILabel!
    @IBOutlet weak var resetButton: UIButton!
    
    
    var segmentedControl: HMSegmentedControl!
    
    var darkOverlay : UIView!
    var loginShown : Bool = true
    
    var loginValidator = Validator()
    var registerValidator = Validator()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideErrors()
        self.setupOverlay()
        self.setupSegmentedControl()
        self.setupValidators()
        self.switchView()
        self.toggleNavBar(true)
        self.setRestraints()
    }
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return UIStatusBarStyle.LightContent
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.toggleNavBar(false)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func loginPressed(sender: AnyObject) {
        loginValidator.validate(self)
    }
    
    @IBAction func registerPressed(sender: AnyObject) {
        self.hideErrors()
        registerValidator.validate(self)
    }
    
    func processLogin() {
        self.toggleForm(true, enabled: false)
        self.toggleOverlay(false)
        self.toggleLoading(true)
        
        EZLoadingActivity.show("Logging you in...", disableUI: true)
        
        let parameters : [String : String] = [
            "cruz_id" : loginCruzId.text!,
            "password" : loginGoldPassword.text!,
        ]
        
        Alamofire.request(.POST, "https://pokeademics.com/login", parameters: parameters)
            .responseJSON { response in
                
                let json = JSON(data: response.data!)
                self.toggleLoading(false)
                
                if(json["error"].stringValue != "") {
                    EZLoadingActivity.hide()
                    self.instantOverlay(true)
                    SCLAlertView().showError("Whoops!", subTitle: json["error"].stringValue)
                    self.toggleForm(true, enabled: true)
                } else {
                    EZLoadingActivity.hide(success: true, animated: true)
                    self.setupKeychain(json["token"].stringValue)
                    self.finishLogin()
                }
                
                print(json)
        }
    }
    
    func processRegister() {
        self.toggleForm(false, enabled: false)
        self.toggleOverlay(false)
        self.toggleLoading(true)
        
        EZLoadingActivity.show("Creating your account...", disableUI: true)
        
        generateTokens()
    }
    
    func finishLogin() {
        let myDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        myDelegate.switchToTabBar()
    }
    
    func finishRegister(first_token : String, second_token : String) {
        
        let parameters : [String : String] = [
            "cruz_id" : registerCruzId.text!,
            "cruz_password" : registerGoldPassword.text!,
            "birth_day" : registerDay.text!,
            "birth_month" : registerMonth.text!,
            "birth_year" : registerYear.text!,
            "first_token" : first_token,
            "second_token" : second_token,
            "device_token" : (UIApplication.sharedApplication().delegate as! AppDelegate).token
        ]
        
        print(parameters)
        
        Alamofire.request(.POST, "https://pokeademics.com/register", parameters: parameters)
            .responseJSON { response in
                
                EZLoadingActivity.hide()
                
                let json = JSON(data: response.data!)
                
                if(json["error"].stringValue != "") {
                    self.instantOverlay(true)
                    SCLAlertView().showError("Whoops!", subTitle: json["error"].stringValue)
                    self.toggleForm(false, enabled: true)
                } else {
                    self.setupPusher(json["channel"].stringValue)
                    self.setupKeychain(json["token"].stringValue)
                }
                
                print(json)
        }
    }
    
    func setupPusher(user_channel : String) {
        EZLoadingActivity.show("Fetching your classes...", disableUI: true)
        
        let pusher = Pusher(key: "cdbe174a7af8b41b5150")
        pusher.connect()
        
        let channel = pusher.subscribe(user_channel)
        
        channel.bind("register", callback: { (data: AnyObject?) -> Void in
            
            print(JSON(data!))

            self.fetchedClasses(JSON(data!))
            
            pusher.disconnect()
        })
    }
    
    func setupKeychain(jwt_token : String) {
        let keychain = KeychainSwift()
        keychain.set(jwt_token, forKey: "jwt_token")
    }
    
    func fetchedClasses(json : JSON) {
        
        EZLoadingActivity.hide(success: true, animated: true)
       
        let seconds = 1.0
        let delay = seconds * Double(NSEC_PER_SEC)
        let dispatchTime = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
        
        dispatch_after(dispatchTime, dispatch_get_main_queue(), {
            
            self.toggleOverlay(true)
            self.toggleLoading(false)
            
        })
        
        var classes = [SchoolClass]()
        
        for(_, subJson) in json["data"] {
            
            classes.append(
                SchoolClass(
                    class_number: subJson["class_number"].stringValue,
                    class_prefix: subJson["class_prefix"].stringValue,
                    class_id: subJson["class_id"].stringValue,
                    class_title: subJson["class_title"].stringValue,
                    type: subJson["type"].stringValue,
                    days: subJson["days"].stringValue,
                    times: subJson["times"].stringValue,
                    instructors: subJson["instructors"].stringValue,
                    location: subJson["location"].stringValue
                )
            )
            
        }
        
        let classesVC = self.storyboard?.instantiateViewControllerWithIdentifier("ClassesViewController") as! ClassesViewController
        classesVC.classes = classes
        
        self.navigationController?.pushViewController(classesVC, animated: true)
    }
    
    func toggleForm(loginForm : Bool, enabled : Bool) {
        if(loginForm) {
            loginCruzId.enabled = enabled
            loginGoldPassword.enabled = enabled
            loginButton.enabled = enabled
        } else {
            registerCruzId.enabled = enabled
            registerGoldPassword.enabled = enabled
            registerButton.enabled = enabled
            registerDay.enabled = enabled
            registerMonth.enabled = enabled
            registerYear.enabled = enabled
            paymentField.enabled = enabled
        }
    }
    
    func setupOverlay() {
        darkOverlay = UIView(frame: view.frame)
        darkOverlay.backgroundColor = UIColor.blackColor()
        darkOverlay.alpha = 0
        
        self.view.addSubview(darkOverlay)
    }
    
    func toggleOverlay(hidden : Bool) {
        self.view.bringSubviewToFront(darkOverlay)
        
        UIView.animateWithDuration(0.35, delay: 0, options: UIViewAnimationOptions.CurveLinear, animations: {
            
            self.darkOverlay.alpha = (hidden ? 0 : 0.65)
            
        }, completion: nil)
    }
    
    func instantOverlay(hidden : Bool) {
        self.darkOverlay.alpha = (hidden ? 0 : 0.65)
    }
    
    func toggleLoading(toggle : Bool) {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = toggle
    }
    
    func setupSegmentedControl() {
        segmentedControl = HMSegmentedControl(sectionTitles: ["Login", "Register"])
        segmentedControl.addTarget(self, action: "segmentedControlChangedValue:", forControlEvents: .AllEvents)
        segmentedControl.frame = CGRectMake(0, view.frame.height - 55, view.frame.width, 55)
        segmentedControl.selectionIndicatorHeight = 5.0
        segmentedControl.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.grayColor(), NSFontAttributeName: UIFont(name: "Avenir-Heavy", size: 20)!]
        segmentedControl.segmentEdgeInset = UIEdgeInsetsMake(0,10,0,10)
        // segmentedControl.selectionIndicatorColor = UIColor(red: 253.0/255.0, green: 81.0/255.0, blue: 116.0/255.0, alpha: 0.8)
        segmentedControl.selectionIndicatorColor = UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 0.8)
        segmentedControl.selectionStyle = HMSegmentedControlSelectionStyleFullWidthStripe
        segmentedControl.selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationUp
        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.backgroundColor = UIColor(red: 74.0/255.0, green: 106.0/255.0, blue: 145.0/255.0, alpha: 0.3)
        
        self.view.addSubview(segmentedControl)
    }
    
    func switchView() {
        UIView.animateWithDuration(0.20, delay: 0, options: UIViewAnimationOptions.CurveLinear, animations: {
                
            self.loginView.alpha = (self.loginShown ? 1.0 : 0.0)
            self.registerView.alpha = (self.loginShown ? 0.0 : 1.0)
            
        }, completion: nil)
        
        self.toggleForm(!loginShown, enabled: false)
        self.toggleForm(loginShown, enabled: true)
        
        hideErrors()
    }
    
    @IBAction func segmentedControlChangedValue(segment: HMSegmentedControl) {
        loginShown = (segment.selectedSegmentIndex == 0 ? true : false)
        switchView()
    }
    
    func setupValidators() {
        loginValidator.registerField(loginCruzId, errorLabel: loginCruzIdError, rules: [RequiredRule()])
        loginValidator.registerField(loginGoldPassword, errorLabel: loginGoldPasswordError, rules: [RequiredRule()])
        
        registerValidator.registerField(registerCruzId, errorLabel: registerCruzIdError, rules: [RequiredRule()])
        registerValidator.registerField(registerGoldPassword, errorLabel: registerGoldPasswordError, rules: [RequiredRule()])
        registerValidator.registerField(registerMonth, errorLabel: registerDateError, rules: [MonthRule(), RequiredRule()])
        registerValidator.registerField(registerDay, errorLabel: registerDateError, rules: [DayRule(), RequiredRule()])
        registerValidator.registerField(registerYear, errorLabel: registerDateError, rules: [YearRule(), RequiredRule()])
    }
    
    func setRestraints(){
        titleRestraints()
        loginRestraints()
        registerRestraints()
    }
    
    func titleRestraints(){
        // Reset Button
        resetButton.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(view).offset(30)
            make.centerX.equalTo(view)
            //make.left.equalTo(view.snp_leftMargin)
            //make.right.equalTo(view.snp_rightMargin)
        }
        // Title Label
        titleLabel.snp_makeConstraints { (make) -> Void in
            //make.top.equalTo(resetButton.snp_bottom).offset(15)
            make.top.equalTo(view).offset(30)
            make.centerX.equalTo(view)
            make.width.equalTo(view)
        }
        // Title Sublabel
        titleSublabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(titleLabel.snp_bottom).offset(5)
            make.centerX.equalTo(view)
            make.left.equalTo(view.snp_leftMargin)
            make.right.equalTo(view.snp_rightMargin)
        }
    }
    
    func loginRestraints(){
        // Login View
        loginView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(20)
            make.centerY.equalTo(titleSublabel.snp_bottom).dividedBy(2).offset((CGRectGetHeight(self.view.frame)-50)/2)
            // make.height.equalTo(198)
            make.right.equalTo(view).offset(-20)
            // make.bottom.equalTo(view.snp_leftMargin).dividedBy(-1).offset(CGRectGetHeight(self.view.frame)-50)
        }
        
        // ID
        loginCruzId.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(loginView)
            make.left.equalTo(loginView).offset(10)
            make.right.equalTo(loginView).offset(-10)
            make.height.equalTo(65)
        }
        
        // ID Error
        loginCruzIdError.snp_makeConstraints { (make) -> Void in
            make.right.equalTo(loginCruzId)
            make.top.equalTo(loginCruzId).offset(5)
        }
        
        // Password
        loginGoldPassword.snp_makeConstraints { (make) -> Void in
            make.height.equalTo(loginCruzId)
            make.top.equalTo(loginCruzId.snp_bottom)
            make.left.equalTo(loginView).offset(10)
            make.right.equalTo(loginView).offset(-10)
        }
        
        // Password Error
        loginGoldPasswordError.snp_makeConstraints { (make) -> Void in
            make.right.equalTo(loginGoldPassword)
            make.top.equalTo(loginGoldPassword).offset(5)
        }
        
        // Login Button
        loginButton.snp_makeConstraints { (make) -> Void in
            make.height.equalTo(loginCruzId).offset(-20)
            make.top.equalTo(loginGoldPassword.snp_bottom).offset(10)
            make.left.equalTo(loginView).offset(10)
            make.right.equalTo(loginView).offset(-10)
            make.bottom.equalTo(loginView).offset(-10)
        }
    }
    
    func registerRestraints(){
        // Register View
        registerView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(20)
            make.right.equalTo(view).offset(-20)
            make.centerY.equalTo(titleSublabel.snp_bottom).dividedBy(2).offset((CGRectGetHeight(self.view.frame)-50)/2)
            // make.height.equalTo(320)
            // make.bottom.equalTo(view).inset(segmentedControl.frame.height + 20)
        }
        
        // ID
        registerCruzId.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(registerView).offset(10)
            make.right.equalTo(registerView).offset(-10)
            make.top.equalTo(registerView)
            make.height.equalTo(65)
        }
        
        // ID Error
        registerCruzIdError.snp_makeConstraints { (make) -> Void in
            make.right.equalTo(registerCruzId)
            make.top.equalTo(registerCruzId).offset(5)
        }
            
        // Password
        registerGoldPassword.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(registerView).offset(10)
            make.right.equalTo(registerView).offset(-10)
            make.top.equalTo(registerCruzId.snp_bottom)
            make.height.equalTo(registerCruzId)
        }
            
        // Password Error
        registerGoldPasswordError.snp_makeConstraints { (make) -> Void in
            make.right.equalTo(registerGoldPassword)
            make.top.equalTo(registerGoldPassword).offset(5)
        }
            
        // Payment Field
        paymentField.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(registerView).offset(10)
            make.right.equalTo(registerView).offset(-10)
            make.top.equalTo(registerGoldPassword.snp_bottom).offset(10)
            make.height.equalTo(registerCruzId).offset(-20)
        }
            
        // Month
        registerMonth.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(paymentField.snp_bottom).offset(6)
            make.left.equalTo(registerView).offset(10)
            make.width.equalTo(registerMonth)
            make.height.equalTo(registerCruzId)
        }
            
        // Day
        registerDay.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(registerMonth)
            make.left.equalTo(registerMonth.snp_right).offset(10)
            make.width.equalTo(registerMonth)
            make.height.equalTo(registerCruzId)
        }
            
        // Year
        registerYear.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(registerMonth)
            make.left.equalTo(registerDay.snp_right).offset(10)
            make.right.equalTo(registerView).offset(-10)
            make.width.equalTo(registerMonth)
            make.height.equalTo(registerCruzId)
        }
            
        // Date Error
        registerDateError.snp_makeConstraints { (make) -> Void in
            make.right.equalTo(registerYear)
            make.top.equalTo(registerYear).offset(-1)
        }
            
        // Register Button
        registerButton.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(registerView).offset(10)
            make.right.equalTo(registerView).offset(-10)
            make.top.equalTo(registerMonth.snp_bottom).offset(10)
            make.bottom.equalTo(registerView).offset(-10)
            make.height.equalTo(registerCruzId).offset(-20)
        }
    }
    
    func validationSuccessful() {
        hideErrors()
        if(loginShown) {
            processLogin()
        } else {
            processRegister()
        }
    }
    
    func validationFailed(errors:[UITextField:ValidationError]) {
        if (loginShown){
            for (_, error) in loginValidator.errors {
                error.errorLabel?.text = error.errorMessage
                error.errorLabel?.hidden = false
            }
        }else{
            for (_, error) in registerValidator.errors {
                error.errorLabel?.text = error.errorMessage
                error.errorLabel?.hidden = false
            }
        }
    }
    
    func toggleNavBar(hidden : Bool) {
        self.navigationController?.navigationBarHidden = hidden
    }
    
    func hideErrors() {
        loginCruzIdError.hidden = true
        loginGoldPasswordError.hidden = true
        
        registerDateError.hidden = true
        registerCruzIdError.hidden = true
        registerGoldPasswordError.hidden = true
    }
    
    func paymentCardTextFieldDidChange(textField: STPPaymentCardTextField) {
        registerButton.enabled = textField.valid
    }
    
    func generateTokens() {
        let card = paymentField.cardParams
        card.currency = "usd"
        
        STPAPIClient.sharedClient().createTokenWithCard(card) { (first_token, error) -> Void in
            if let error = error  {
                print(error)
            }
            else if let first_token = first_token {
                print(first_token)
                
                if(first_token.card?.funding != STPCardFundingType.Debit)
                {
                    self.instantOverlay(true)
                    EZLoadingActivity.hide()
                    SCLAlertView().showError("Whoops!", subTitle: "The card entered must be a valid Debit card.")
                    self.toggleForm(false, enabled: true)
                    return
                }
                
                STPAPIClient.sharedClient().createTokenWithCard(card) { (second_token, error) -> Void in
                    if let error = error  {
                        print(error)
                    }
                    else if let second_token = second_token {
                        
                        self.finishRegister(String(first_token), second_token: String(second_token))
                    }
                }
            }
        }
    }

    @IBAction func resetPressed(sender: AnyObject) {
        Alamofire.request(.GET, "https://pokeademics.com/reset")
    }
}
