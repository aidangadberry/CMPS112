//
//  UserInfo.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 3/11/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import Foundation

struct UserInfo {
    let id : String
    let cruz_id : String
    let birth_date : String
    let cruz_email : String
    let cruz_first_name : String
    let cruz_last_name : String
    let live_bets : String
    let completed_bets : String
    let classes : [ClassInfo]
}

struct ClassInfo {
    let id : String
    let user_id : String
    let class_number : String
    let class_prefix : String
    let class_title : String
    let type : String
    let days : String
    let class_id : String
    let times : String
    let instructors : String
    let location : String
}