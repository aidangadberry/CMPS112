//
//  SchoolClass.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/13/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import Foundation

struct SchoolClass {
    
    let class_number, class_prefix, class_id, class_title,
        type, days, times, instructors, location : String
    
}