//
//  ProfileViewController.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/25/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit
import KeychainSwift
import SnapKit
import Alamofire
import AlamofireImage
import SCLAlertView

class ProfileViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var logout: UIButton!
    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var imageLayout: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var classes: UILabel!
    
    @IBOutlet weak var classesTableView: UITableView!
    
    var gravatar: Gravatar!
    
    var info: UserInfo!
    
    lazy var placeholderImage: UIImage = {
        let image = UIImage(named: "Placeholder Image")!
        return image
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initializeNavBar()
        self.setConstraints()
        self.drawLines()
        
        self.createProfilePicture()
        self.initializeLabels()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func initializeNavBar() {
        navBar.frame = CGRectMake(0, 0, self.view.frame.width, 64)
        navBar.barTintColor = UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 1)
        
        navBar.tintColor = UIColor.whiteColor()
        navBar.barStyle = UIBarStyle.Black
        
        navBar.titleTextAttributes = [
            NSFontAttributeName : UIFont(name: "Avenir-Heavy", size: 18.0)!,
            NSForegroundColorAttributeName : UIColor.whiteColor()
        ]
        
        navBar.topItem!.title = "Profile"
        
        let logout = UIBarButtonItem(title: "Logout", style: .Plain, target: self, action: "addTapped")
        navigationItem.rightBarButtonItem = logout
    }
    
    func getMyInfo() {
        Alamofire.request(.GET, "https://pokeademics.com/api/v1/me", headers: self.getHeaders())
            .responseJSON { response in
                
                let json = JSON(data: response.data!)
                
                if(json["error"].stringValue != "") {
                    SCLAlertView().showError("Whoops!", subTitle: json["error"].stringValue)
                } else {
                    self.processData(json)
                }
                
                print(json)
        }
    }
    
    func processData(json : JSON) {
        var classes = [ClassInfo]()
        
        for(_, jsonUser) in json["classes"] {
            classes.append(
                ClassInfo(
                    id: jsonUser["id"].stringValue,
                    user_id: jsonUser["user_id"].stringValue,
                    class_number: jsonUser["class_number"].stringValue,
                    class_prefix: jsonUser["class_prefix"].stringValue,
                    class_title: jsonUser["class_title"].stringValue,
                    type: jsonUser["type"].stringValue,
                    days: jsonUser["days"].stringValue,
                    class_id: jsonUser["class_id"].stringValue,
                    times: jsonUser["times"].stringValue,
                    instructors: jsonUser["instructors"].stringValue,
                    location: jsonUser["location"].stringValue
                )
            )
        }
        
        info = UserInfo(
            id: json["id"].stringValue,
            cruz_id: json["cruz_id"].stringValue,
            birth_date: json["birth_date"].stringValue,
            cruz_email: json["cruz_email"].stringValue,
            cruz_first_name: json["cruz_first_name"].stringValue,
            cruz_last_name: json["cruz_last_name"].stringValue,
            live_bets: json["live_bets"].stringValue,
            completed_bets: json["completed_bets"].stringValue,
            classes: classes
        )
    }
    
    func getHeaders() -> [String : String] {
        let keychain = KeychainSwift()
        let token = keychain.get("jwt_token")
        
        return [
            "Authorization" : "Bearer " + token!
        ]
    }
    
    func createProfilePicture(){
        gravatar = Gravatar(emailAddress: info.cruz_email, defaultImage: .Identicon)
        profileImage.contentMode = .ScaleAspectFit
        
        let URL = gravatar.URL(size: 120)
        
        profileImage.af_setImageWithURL(
            URL,
            placeholderImage: nil,
            filter: nil,
            imageTransition: .None
        )
        
        profileImage.layer.borderWidth = 0.0
        profileImage.layer.borderColor = (UIColor.blackColor()).CGColor
        profileImage.layer.cornerRadius = 60
        profileImage.clipsToBounds = true
        profileImage.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
    }
    
    func drawLines() {
        // Setup our context
        UIGraphicsBeginImageContextWithOptions(CGSize(width: self.view.layer.frame.width, height: self.view.layer.frame.height), false, 0)
        let context = UIGraphicsGetCurrentContext()
        
        // Setup complete, do drawing here
        CGContextSetStrokeColorWithColor(context, UIColor.whiteColor().CGColor)
        CGContextSetLineWidth(context, 1.0)
        
        CGContextBeginPath(context)
        CGContextMoveToPoint(context, 20, 224)
        CGContextAddLineToPoint(context, self.view.layer.frame.width - 20, 224)
        CGContextMoveToPoint(context, 160, 224)
        CGContextAddLineToPoint(context, 160, 84)
        CGContextStrokePath(context)

        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        imageLayout.image = img
    }
    
    
    
    @IBAction func logoutPressed(sender: AnyObject) {
        let alertView = SCLAlertView()
        alertView.addButton("Yes") {
            let keychain = KeychainSwift()
            keychain.delete("jwt_token")
            
            let myDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            myDelegate.landingNav()
        }
        alertView.addButton("No") {}
        alertView.showCloseButton = false
        alertView.showInfo("Warning:", subTitle: "Are you sure you want to log out?")
    }
    
    func setConstraints() {
        name.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(profileImage.snp_right).offset(40)
            make.top.equalTo(profileImage).offset(5)
        }
        
        email.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(name)
            make.top.equalTo(name.snp_bottom).offset(10)
        }
        
        logout.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(name)
            make.bottom.equalTo(profileImage)
            make.right.equalTo(view).offset(-20)
        }
        
        classes.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.top.equalTo(profileImage.snp_bottom).offset(50)
        }
        
        classesTableView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view)
            make.right.equalTo(view)
            make.bottom.equalTo(view).offset(-55)
            make.top.equalTo(classes.snp_bottom).offset(10)
        }
    }
    
    func initializeLabels() {
        name.text = info.cruz_first_name + " " + info.cruz_last_name
        email.text = info.cruz_email
        
        logout.layer.borderWidth = 2.0
        logout.layer.borderColor = (UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 1)).CGColor
        logout.layer.cornerRadius = 4
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ProfileTableViewCell") as! ProfileTableViewCell
        
        //class_id + ": " + class_title
        
        cell.className.text = info.classes[indexPath.row].class_id + ": " + info.classes[indexPath.row].class_title
        cell.classLocation.text = info.classes[indexPath.row].location
        cell.classInstructors.text = info.classes[indexPath.row].instructors
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return info.classes.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 100.0
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)

        UIApplication.sharedApplication().statusBarStyle = UIStatusBarStyle.LightContent

    }
}
