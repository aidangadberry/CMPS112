//
//  ProfileTableViewCell.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 3/12/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var className: UILabel!
    @IBOutlet weak var classLocation: UILabel!
    @IBOutlet weak var classInstructors: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
