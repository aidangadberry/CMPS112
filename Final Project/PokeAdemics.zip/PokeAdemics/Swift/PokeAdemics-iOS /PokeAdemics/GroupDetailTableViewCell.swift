//
//  GroupDetailTableViewCell.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 2/28/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit
import SnapKit

class GroupDetailTableViewCell: UITableViewCell {

    @IBOutlet weak var view: UIView!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setConstraints()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        //super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setConstraints(){
        profileImage.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(5)
            make.top.equalTo(view).offset(5)
            make.bottom.equalTo(view).offset(-5)
        }
        
        userName.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(profileImage.snp_right).offset(5)
            make.centerY.equalTo(view)
        }
    }

}
