//
//  GroupsNavigationController.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/25/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit

class GroupsNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupNavBar()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setupNavBar() {
        self.navigationBar.barTintColor = UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 1)
        self.navigationBar.tintColor = UIColor.whiteColor()
        self.navigationBar.barStyle = UIBarStyle.Black
        
        self.navigationBar.titleTextAttributes = [
            NSFontAttributeName : UIFont(name: "Avenir-Heavy", size: 18.0)!,
            NSForegroundColorAttributeName : UIColor.whiteColor()
        ]
    }
    
}
