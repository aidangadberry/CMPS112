//
//  ClassTableViewCell.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/13/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit

class ClassTableViewCell: UITableViewCell {

    @IBOutlet weak var classNameLabel: UILabel!
    @IBOutlet weak var classLocationLabel: UILabel!
    @IBOutlet weak var classInstructorsLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        //super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
