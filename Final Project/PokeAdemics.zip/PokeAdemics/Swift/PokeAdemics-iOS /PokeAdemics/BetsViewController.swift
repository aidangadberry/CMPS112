//
//  BetsViewController.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 2/23/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit
import HMSegmentedControl
import SnapKit
import EZLoadingActivity
import Alamofire
import SCLAlertView
import KeychainSwift

class BetsViewController: UIViewController {
    
    var segmentedControl: HMSegmentedControl!
    var groups = [BetGroup]()
    var groupSections = [String]()
    
    var darkOverlay : UIView!
    @IBOutlet weak var activeView: UIView!
    @IBOutlet weak var completeView: UIView!
    
    @IBOutlet weak var activeTableView: UITableView!
    @IBOutlet weak var statsView: UIView!
    
    @IBOutlet weak var inPlay: UILabel!
    @IBOutlet weak var potentialEarnings: UILabel!
    
    
    var activeShown : Bool = true
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: "handleRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        
        return refreshControl
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "My Bets"
        
        self.setRestraints()
        self.setupSegmentedControl()
        self.setupRefresh()
        self.setupOverlay()
        self.initializeLabels()
    }

    func setupSegmentedControl() {
        segmentedControl = HMSegmentedControl(sectionTitles: ["In Progress", "Complete"])
        segmentedControl.addTarget(self, action: "segmentedControlChangedValue:", forControlEvents: .AllEvents)
        segmentedControl.frame = CGRectMake(0, 64, view.frame.width, 50)
        segmentedControl.selectionIndicatorHeight = 5.0
        segmentedControl.titleTextAttributes = [NSForegroundColorAttributeName: UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 0.7), NSFontAttributeName: UIFont(name: "Avenir-Heavy", size: 20)!]
        segmentedControl.segmentEdgeInset = UIEdgeInsetsMake(0,10,0,10)
        segmentedControl.selectionIndicatorColor = UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 0.8)
        segmentedControl.selectionStyle = HMSegmentedControlSelectionStyleFullWidthStripe
        segmentedControl.selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationDown
        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.backgroundColor = UIColor(red: 74.0/255.0, green: 106.0/255.0, blue: 145.0/255.0, alpha: 0.3)
        
        self.view.addSubview(segmentedControl)
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ActiveTableViewCell") as! ActiveTableViewCell
        
        let sectionItems = getSectionItems(indexPath.section)
        
        if(!sectionItems.isEmpty) {
            let group = sectionItems[indexPath.row] as BetGroup
            
            cell.activeName.text = group.name
            cell.activeUsersCount.text = String(group.users_count) + " students"
            
            cell.activeBuyIn.text = "$" + String(format: "%.2f", group.buy_in)
            cell.activePayoutCount.text = "Top " + String(group.pool_payout_count)
            cell.activePoolTotal.text = "$" + String(format: "%.2f", group.pool_total)
        }
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getSectionItems(section).count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 100.0
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(!groupSections.isEmpty) {
            return groupSections[section]
        } else {
            return ""
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return groupSections.count
    }
    
    func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let header : UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView
        
        header.backgroundView?.backgroundColor = UIColor(red: 74.0/255.0, green: 106.0/255.0, blue: 145.0/255.0, alpha: 1.0)
        header.textLabel!.textColor = UIColor.whiteColor()
        header.textLabel!.font = UIFont(name: "Avenir-Medium", size: 15)
        header.textLabel!.frame = header.frame
        header.textLabel!.textAlignment = NSTextAlignment.Left
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let sectionItems = getSectionItems(indexPath.section)
        let group = sectionItems[indexPath.row] as BetGroup
        
        let groupDetailVC = self.storyboard?.instantiateViewControllerWithIdentifier("GroupDetailViewController") as! GroupDetailViewController
        groupDetailVC.betGroup = group
        self.navigationController?.pushViewController(groupDetailVC, animated: true)
        
    }
    
    func getGroups() {
        groups.removeAll()
        
        self.toggleOverlay(false)
        self.toggleLoading(true)
        EZLoadingActivity.show("Fetching bets...", disableUI: true)
        
        Alamofire.request(.GET, "https://pokeademics.com/api/v1/groups/joined", headers: self.getHeaders())
            .responseJSON { response in
                
                EZLoadingActivity.hide()
                self.toggleLoading(false)
                self.toggleOverlay(true)
                
                let json = JSON(data: response.data!)
                
                if(json["error"].stringValue != "") {
                    self.instantOverlay(true)
                    SCLAlertView().showError("Whoops!", subTitle: json["error"].stringValue)
                } else {
                    self.processData(json)
                    self.setTabBarBadge()
                    self.initializeLabels()
                }
                
                print(json)
        }
    }
    
    func processData(json : JSON) {
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        for(_, subJson) in json {
            
            var users = [UserGroup]()
            
            for(_, jsonUser) in subJson["user_groups"] {
                users.append(
                    UserGroup(
                        cruz_id: jsonUser["cruz_id"].stringValue,
                        cruz_first_name: jsonUser["cruz_first_name"].stringValue,
                        cruz_last_name: jsonUser["cruz_last_name"].stringValue,
                        group_id: jsonUser["group_id"].stringValue,
                        id: jsonUser["id"].stringValue,
                        pool_paid: jsonUser["pool_paid"].doubleValue,
                        winner: jsonUser["winner"].stringValue,
                        pool_place: jsonUser["pool_place"].stringValue,
                        pool_won: jsonUser["pool_won"].doubleValue
                    )
                )
            }
            
            let schoolClass = GroupClass(
                class_number: subJson["school_class"]["class_number"].stringValue,
                class_id: subJson["school_class"]["class_id"].stringValue,
                class_title: subJson["school_class"]["class_title"].stringValue,
                times: subJson["school_class"]["times"].stringValue,
                days: subJson["school_class"]["days"].stringValue,
                instructors: subJson["school_class"]["instructors"].stringValue,
                location: subJson["school_class"]["location"].stringValue
            )
            
            let group = BetGroup(
                id: subJson["id"].stringValue,
                class_id: subJson["class_id"].stringValue,
                owner_id: subJson["owner_id"].stringValue,
                name: subJson["name"].stringValue,
                isPublic: subJson["public"].boolValue,
                joinable: subJson["joinable"].boolValue,
                class_default: subJson["class_default"].boolValue,
                complete: subJson["complete"].boolValue,
                users_count: subJson["users_count"].intValue,
                buy_in: subJson["buy_in"].doubleValue,
                pool_total: subJson["pool_total"].doubleValue,
                pool_payout_count: subJson["pool_payout_count"].intValue,
                created_at: dateFormatter.dateFromString(subJson["created_at"].stringValue)!,
                updated_at: dateFormatter.dateFromString(subJson["updated_at"].stringValue)!,
                users: users,
                school_class: schoolClass
            )
            
            groups.append(group)
            
        }
        getSections()
    }

    func getSections() {
        groupSections.removeAll()
        
        for group : BetGroup in groups {
            if (activeShown) {
                if (!group.complete) {
                    let title = (group.school_class).class_id + ": " + (group.school_class).class_title
                    if(!groupSections.contains(title)) {
                        groupSections.append(title)
                    }
                }
            } else {
                if (group.complete) {
                    let title = (group.school_class).class_id + ": " + (group.school_class).class_title
                    if(!groupSections.contains(title)) {
                        groupSections.append(title)
                    }
                }
            }
        }
        
        self.activeTableView.reloadData()
    }
    
    func instantOverlay(hidden : Bool) {
        self.darkOverlay.alpha = (hidden ? 0 : 0.65)
    }
    
    func toggleLoading(toggle : Bool) {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = toggle
    }
    
    func toggleOverlay(hidden : Bool) {
        self.view.bringSubviewToFront(darkOverlay)
        
        UIView.animateWithDuration(0.35, delay: 0, options: UIViewAnimationOptions.CurveLinear, animations: {
            
            self.darkOverlay.alpha = (hidden ? 0 : 0.65)
            
            }, completion: nil)
    }
    
    func getSectionItems(section : Int) -> [BetGroup] {
        var result : [BetGroup] = []
        
        for group : BetGroup in self.groups
        {
            if(!self.groupSections.isEmpty)
            {
                let title = (group.school_class).class_id + ": " + (group.school_class).class_title
                if(title == self.groupSections[section])
                {
                    result.append(group)
                }
            }
        }
        
        return result
    }
    
    func setTabBarBadge() {
        let tabArray = self.tabBarController?.tabBar.items as NSArray!
        let tabItem = tabArray.objectAtIndex(1) as! UITabBarItem
        
        let activeCount = self.activeCount()
        
        if (activeCount > 0) {
            tabItem.badgeValue = String(activeCount)
        }
    }
    
    func activeCount() -> Int {
        var count : Int = 0
        for group : BetGroup in self.groups {
            if (group.complete == false) {
                count++
            }
        }
        print(count)
        return count
    }
    
    func getHeaders() -> [String : String] {
        
        let keychain = KeychainSwift()
        let token = keychain.get("jwt_token")
        
        return [
            "Authorization" : "Bearer " + token!
        ]
    }
    
    func setupOverlay() {
        darkOverlay = UIView(frame: view.frame)
        darkOverlay.backgroundColor = UIColor.blackColor()
        darkOverlay.alpha = 0
        
        self.view.addSubview(darkOverlay)
    }
    
    func setupRefresh() {
        self.activeTableView.addSubview(self.refreshControl)
    }
    
    func handleRefresh(refreshControl: UIRefreshControl) {
        groups = []
        groupSections = []
        
        self.getGroups()
        refreshControl.endRefreshing()
    }
    
    func initializeLabels(){
        self.inPlay.text = "You currently have $" + String(format: "%.2f", totalBuyIns()) + " invested into your active bet groups"
        self.inPlay.boldSubstring("$" + String(format: "%.2f", totalBuyIns()))
        self.potentialEarnings.text = "You have the potential to win $" + String(format: "%.2f", totalPoolTotals()) + " from all of your active bet groups"
        self.potentialEarnings.boldSubstring("$" + String(format: "%.2f", totalPoolTotals()))
    }
    
    func totalBuyIns() -> Double {
        var total : Double = 0.0
        for group : BetGroup in self.groups {
            if (group.complete == false) {
                total += group.buy_in
            }
        }
        return total
    }
    
    func totalPoolTotals() -> Double {
        var total : Double = 0.0
        for group : BetGroup in self.groups {
            if (group.complete == false) {
                total += group.pool_total
            }
        }
        return total
    }
    
    func setRestraints() {
        activeRestraints()
        completeRestraints()
    }
    
    func activeRestraints() {
        activeView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(view).offset(114)
            make.left.equalTo(view)
            make.right.equalTo(view)
            make.bottom.equalTo(view).offset(-55)
        }
        
        activeTableView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(activeView)
            make.left.equalTo(activeView)
            make.right.equalTo(activeView)
            make.bottom.equalTo(statsView.snp_top).offset(-20)
        }
        
        statsView.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(view).offset(20)
            make.right.equalTo(view).offset(-20)
            make.bottom.equalTo(view).offset(-75)
        }
        
        inPlay.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(statsView).offset(10)
            make.top.equalTo(statsView).offset(5)
            make.right.equalTo(statsView).offset(-10)
            make.height.equalTo(60)
        }
        
        potentialEarnings.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(inPlay.snp_bottom).offset(5)
            make.left.equalTo(statsView).offset(10)
            make.bottom.equalTo(statsView).offset(-5)
            make.right.equalTo(statsView).offset(-10)
            make.height.equalTo(inPlay)
        }
    }
    
    func completeRestraints() {
        completeView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(view).offset(114)
            make.left.equalTo(view)
            make.right.equalTo(view)
            make.bottom.equalTo(view).offset(-55)
        }
    }
    
    @IBAction func segmentedControlChangedValue(segment: HMSegmentedControl) {
        activeShown = (segment.selectedSegmentIndex == 0 ? true : false)
        getSections()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
