//
//  ActiveTableViewCell.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 3/9/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit

class ActiveTableViewCell: UITableViewCell {

    @IBOutlet weak var activeName: UILabel!
    @IBOutlet weak var activeUsersCount: UILabel!
    @IBOutlet weak var activePoolTotal: UILabel!
    @IBOutlet weak var activePayoutCount: UILabel!
    @IBOutlet weak var activeBuyIn: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        //super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
