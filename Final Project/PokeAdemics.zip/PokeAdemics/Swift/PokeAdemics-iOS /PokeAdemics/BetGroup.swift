//
//  BetGroup.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 2/24/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import Foundation

struct BetGroup {
    let id : String //
    let class_id : String //
    let owner_id : String //
    let name : String //
    let isPublic : Bool //
    let joinable : Bool //
    let class_default : Bool //
    let complete : Bool //
    let users_count : Int //
    let buy_in : Double //
    let pool_total : Double //
    let pool_payout_count : Int //
    let created_at : NSDate //
    let updated_at : NSDate //
    var users : [UserGroup]
    let school_class : GroupClass
}

struct UserGroup {
    let cruz_id : String //
    let cruz_first_name : String //
    let cruz_last_name : String //
    let group_id : String //
    let id : String
    let pool_paid: Double
    let winner: String
    let pool_place: String
    let pool_won: Double
}

struct GroupClass {
    let class_number : String //
    let class_id : String //
    let class_title : String //
    let times : String //
    let days : String //
    let instructors : String //
    let location : String //
}