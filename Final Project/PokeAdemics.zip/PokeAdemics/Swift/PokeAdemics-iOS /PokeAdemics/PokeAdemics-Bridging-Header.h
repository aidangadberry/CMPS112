//
//  PokeAdemics-Bridging-Header.h
//  PokeAdemics
//
//  Created by Aidan Gadberry on 3/11/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

#ifndef PokeAdemics_Bridging_Header_h
#define PokeAdemics_Bridging_Header_h

#import <CommonCrypto/CommonCrypto.h>

#endif /* PokeAdemics_Bridging_Header_h */
