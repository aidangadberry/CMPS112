//
//  GroupTableViewCell.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/27/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit

class GroupTableViewCell: UITableViewCell {
    
    @IBOutlet weak var groupName: UILabel!
    @IBOutlet weak var groupUsersCount: UILabel!
    @IBOutlet weak var groupBuyIn: UILabel!
    @IBOutlet weak var groupPoolTotal: UILabel!
    @IBOutlet weak var groupPayoutCount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        //super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
