//
//  HomeTabBarController.swift
//  PokeAdemics
//
//  Created by Aidan Gadberry on 2/23/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit

class HomeTabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Sets the default color of the icon of the selected UITabBarItem and Title
        //UITabBar.appearance().tintColor = UIColor(red: 125.0/255.0, green: 157.0/255.0, blue: 196.0/255.0, alpha: 1.0)
        UITabBar.appearance().tintColor = UIColor.whiteColor()
        // 74 106 145   125  157  196
        
        // Sets the default color of the background of the UITabBar
        UITabBar.appearance().barTintColor = UIColor(red: 0.141, green: 0.165, blue: 0.224, alpha: 1)
        
        // UITabBar text attributes
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.whiteColor(), NSFontAttributeName: UIFont(name: "Avenir-Heavy", size: 15)!], forState: .Selected)
        
        UITabBarItem.appearance().setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Avenir-Heavy", size: 15)!], forState: .Normal)
        
        (self.viewControllers![2] as! ProfileViewController).getMyInfo()
        
        let navVC = self.viewControllers![1] as! BetsNavigationController
        let betsVC = navVC.viewControllers[0] as! BetsViewController
        betsVC.getGroups()
        
        //UITabBar.appearance().selectedImageTintColor = UIColor.whiteColor()
    }
    
        // 36 42 57
    override func viewWillLayoutSubviews() {
        var tabFrame = self.tabBar.frame
        // - 40 is editable , I think the default value is around 50 px, below lowers the tabbar and above increases the tab bar size
        let height: CGFloat = 55
        tabFrame.size.height = height
        tabFrame.origin.y = self.view.frame.size.height - height
        self.tabBar.frame = tabFrame
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
