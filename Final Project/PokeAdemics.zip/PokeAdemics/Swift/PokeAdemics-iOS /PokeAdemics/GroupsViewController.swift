//
//  GroupsViewController.swift
//  PokeAdemics
//
//  Created by Brad Bernard on 2/25/16.
//  Copyright © 2016 Brad Bernard. All rights reserved.
//

import UIKit
import SnapKit
import EZLoadingActivity
import Alamofire
import KeychainSwift
import SCLAlertView

class GroupsViewController: UIViewController {

    @IBOutlet weak var groupsTableView: UITableView!
    
    var groups = [BetGroup]()
    var groupSections = [String]()
    
    var darkOverlay : UIView!
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: "handleRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        
        return refreshControl
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Groups"
        
        self.setupConstraints()
        self.setupRefresh()
        self.setupOverlay()
        self.getGroups()
        
        //navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Create Group", style: .Plain, target: self, action: "addTapped")
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .Compose, target: self, action: "addTapped")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setupRefresh() {
        self.groupsTableView.addSubview(self.refreshControl)
    }
    
    func handleRefresh(refreshControl: UIRefreshControl) {
        groups = []
        groupSections = []
        
        self.getGroups()
        refreshControl.endRefreshing()
    }
    
    func getGroups() {
        groups.removeAll()
        groupSections.removeAll()
        
        self.toggleOverlay(false)
        self.toggleLoading(true)
        EZLoadingActivity.show("Fetching groups...", disableUI: true)
        
        Alamofire.request(.GET, "https://pokeademics.com/api/v1/groups", headers: self.getHeaders())
            .responseJSON { response in
                
                EZLoadingActivity.hide()
                self.toggleLoading(false)
                self.toggleOverlay(true)
                
                let json = JSON(data: response.data!)
                
                if(json["error"].stringValue != "") {
                    self.instantOverlay(true)
                    SCLAlertView().showError("Whoops!", subTitle: json["error"].stringValue)
                } else {
                    self.processData(json)
                }
                
                print(json)
        }
    }
    
    func getHeaders() -> [String : String] {
        
        let keychain = KeychainSwift()
        let token = keychain.get("jwt_token")
        
        return [
            "Authorization" : "Bearer " + token!
        ]
    }
    
    func processData(json : JSON) {

        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        for(_, subJson) in json {
            
            var users = [UserGroup]()
            
            for(_, jsonUser) in subJson["user_groups"] {
                users.append(
                    UserGroup(
                        cruz_id: jsonUser["cruz_id"].stringValue,
                        cruz_first_name: jsonUser["cruz_first_name"].stringValue,
                        cruz_last_name: jsonUser["cruz_last_name"].stringValue,
                        group_id: jsonUser["group_id"].stringValue,
                        id: jsonUser["id"].stringValue,
                        pool_paid: json["data"]["pool_paid"].doubleValue,
                        winner: json["data"]["winner"].stringValue,
                        pool_place: json["data"]["pool_place"].stringValue,
                        pool_won: json["data"]["pool_won"].doubleValue
                    )
                )
            }
            
            let schoolClass = GroupClass(
                class_number: subJson["school_class"]["class_number"].stringValue,
                class_id: subJson["school_class"]["class_id"].stringValue,
                class_title: subJson["school_class"]["class_title"].stringValue,
                times: subJson["school_class"]["times"].stringValue,
                days: subJson["school_class"]["days"].stringValue,
                instructors: subJson["school_class"]["instructors"].stringValue,
                location: subJson["school_class"]["location"].stringValue
            )
            
            let group = BetGroup(
                id: subJson["id"].stringValue,
                class_id: subJson["class_id"].stringValue,
                owner_id: subJson["owner_id"].stringValue,
                name: subJson["name"].stringValue,
                isPublic: subJson["public"].boolValue,
                joinable: subJson["joinable"].boolValue,
                class_default: subJson["class_default"].boolValue,
                complete: subJson["complete"].boolValue,
                users_count: subJson["users_count"].intValue,
                buy_in: subJson["buy_in"].doubleValue,
                pool_total: subJson["pool_total"].doubleValue,
                pool_payout_count: subJson["pool_payout_count"].intValue,
                created_at: dateFormatter.dateFromString(subJson["created_at"].stringValue)!,
                updated_at: dateFormatter.dateFromString(subJson["updated_at"].stringValue)!,
                users: users,
                school_class: schoolClass
            )
            
            groups.append(group)
            
        }
        
        for group : BetGroup in groups
        {
            let title = (group.school_class).class_id + ": " + (group.school_class).class_title
            if(!groupSections.contains(title))
            {
                groupSections.append(title)
            }
        }
        
        self.groupsTableView.reloadData()
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let sectionItems = getSectionItems(indexPath.section)
        let group = sectionItems[indexPath.row] as BetGroup
        
        let groupDetailVC = self.storyboard?.instantiateViewControllerWithIdentifier("GroupDetailViewController") as! GroupDetailViewController
        groupDetailVC.betGroup = group
        self.navigationController?.pushViewController(groupDetailVC, animated: true)

    }
    
    func setupOverlay() {
        darkOverlay = UIView(frame: view.frame)
        darkOverlay.backgroundColor = UIColor.blackColor()
        darkOverlay.alpha = 0
        
        self.view.addSubview(darkOverlay)
    }
    
    func toggleOverlay(hidden : Bool) {
        self.view.bringSubviewToFront(darkOverlay)
        
        UIView.animateWithDuration(0.35, delay: 0, options: UIViewAnimationOptions.CurveLinear, animations: {
            
            self.darkOverlay.alpha = (hidden ? 0 : 0.65)
            
            }, completion: nil)
    }
    
    func instantOverlay(hidden : Bool) {
        self.darkOverlay.alpha = (hidden ? 0 : 0.65)
    }
    
    func toggleLoading(toggle : Bool) {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = toggle
    }
    
    func getSectionItems(section : Int) -> [BetGroup] {
        var result : [BetGroup] = []
        
        for group : BetGroup in self.groups
        {
            if(!self.groupSections.isEmpty)
            {
                let title = (group.school_class).class_id + ": " + (group.school_class).class_title
                if(title == self.groupSections[section])
                {
                    result.append(group)
                }
            }
        }
        
        return result
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("GroupTableViewCell") as! GroupTableViewCell
        
        let sectionItems = getSectionItems(indexPath.section)
        
        if(!sectionItems.isEmpty) {
            let group = sectionItems[indexPath.row] as BetGroup
            
            cell.groupName.text = group.name
            cell.groupUsersCount.text = String(group.users_count) + " students"
            
            cell.groupBuyIn.text = "$" + String(format: "%.2f", group.buy_in)
            cell.groupPayoutCount.text = "Top " + String(group.pool_payout_count)
            cell.groupPoolTotal.text = "$" + String(format: "%.2f", group.pool_total)
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getSectionItems(section).count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 100.0
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(!groupSections.isEmpty) {
            return groupSections[section]
        } else {
            return ""
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return groupSections.count
    }
    
    func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let header : UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView
        
        header.backgroundView?.backgroundColor = UIColor(red: 74.0/255.0, green: 106.0/255.0, blue: 145.0/255.0, alpha: 1.0)
        header.textLabel!.textColor = UIColor.whiteColor()
        header.textLabel!.font = UIFont(name: "Avenir-Medium", size: 15)
        header.textLabel!.frame = header.frame
        header.textLabel!.textAlignment = NSTextAlignment.Left
    }
    
    func setupConstraints() {
        groupsTableView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(64)
            make.left.equalTo(self.view)
            make.bottom.equalTo(self.view).offset(-55)
            make.right.equalTo(self.view)
        }
    }
    
    func addGroups() -> [BetGroup] {
        var ret = [BetGroup]()
        var classIds = [String]()
        for group in self.groups {
            if(!classIds.contains(group.school_class.class_number)) {
                ret.append(group)
                classIds.append(group.school_class.class_number)
            }
        }
        return ret
    }
    
    func addTapped() {
        let groupAddVC = self.storyboard?.instantiateViewControllerWithIdentifier("GroupAddViewController") as! GroupAddViewController
        groupAddVC.groups = self.addGroups()
        
        self.presentViewController(groupAddVC, animated: true, completion: nil)
    }
    
}
